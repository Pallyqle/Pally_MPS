﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace CloudMM
{
    public partial class CloudMM : Form
    {
        string CMM_GetLFG = "http://pallyqle.dx.am/CMM_GetLFG.php";
        string CMM_SharedGroupInfo = "http://pallyqle.dx.am/CMM_SharedGroupInfo.php";
        string CMM_SetMatchCounter = "http://pallyqle.dx.am/CMM_SetMatchCounter.php";
        string CMM_LFG = "http://pallyqle.dx.am/CMM_LFG.php";

        List<LFG> lfg = new List<LFG>();
        List<ReadyGroups> readyGroups = new List<ReadyGroups>();

        int playerToStart = 0;
        int DefaultTimerCount = 0;

        public CloudMM()
        {
            InitializeComponent();
        }

        private void CloudMM_Load(object sender, EventArgs e)
        {

        }

        private string ProcessURL(string url, string method, string post)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] data = encoding.GetBytes(post);
            string rc = "";
            WebRequest request = WebRequest.Create(url);

            request.Method = method;
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;

            try
            {
                Stream stream = request.GetRequestStream();
                stream.Write(data, 0, data.Length);
                stream.Close();

                WebResponse response = request.GetResponse();
                stream = response.GetResponseStream();

                StreamReader sr = new StreamReader(stream);
                rc = sr.ReadToEnd();
            }
            catch (WebException e)
            {
                ETB_Return.Text = "Connection Error";
            }
            return rc;
        }
        private bool CheckValidRC(string rc)
        {
            if (rc.Contains("Error"))
            {
                switch (rc)
                {
                    case "Error0":
                        rc = "Connection Error";
                        break;
                    case "Error1":
                        rc = "No LFG Found";
                        break;
                    default:
                        break;
                }
                ETB_Return.Text = rc;
                return false;
            }
            else
            {
                return true;
            }
        }
        private void GetLFG_Tick(object sender, EventArgs e)
        {
            ETB_Return.Text = "";

            string post = "";
            string url = CMM_GetLFG;
            string method = "POST";
            string rc = "";

            rc = ProcessURL(url, method, post);

            if (CheckValidRC(rc))
            {
                string[] rcp = rc.Split(new char[1] { ';' });

                foreach (string x in rcp)
                {
                    if (x != "")
                    {
                        LFG l_LFG;
                        string[] l_LfgInfo = x.Split(new char[1] { '/' });
                        bool l_IsFound = false;
                        int l_Index = 0;

                        l_LFG.Requester = l_LfgInfo[0];
                        l_LFG.Members = l_LfgInfo[1];
                        l_LFG.HostRequest = l_LfgInfo[2];
                        l_LFG.GameType = l_LfgInfo[3];
                        l_LFG.TeamCount = l_LfgInfo[4];
                        l_LFG.MNP = Int16.Parse(l_LfgInfo[5]);
                        l_LFG.IsCanceled = l_LfgInfo[6];

                        for (int i = 0; i < lfg.Count; i++)
                        {
                            l_Index = i;
                            if (lfg[i].Members.Contains(l_LFG.Requester))
                            {
                                l_IsFound = true;
                                break;
                            }
                        }
                        if (l_LFG.IsCanceled == "1")
                        {
                            CancelLFG(l_LFG);
                        }
                        else
                        {
                            if (!l_IsFound)
                            {
                                lfg.Add(l_LFG);
                                if (!MatchGroups.Enabled)
                                {
                                    MatchGroups.Enabled = true;
                                }
                                if (l_LFG.Members != "")
                                {
                                    LFGAction(l_LFG, "Started");
                                }
                            }
                        }
                    }
                }
            }
        }
        private void MatchGroups_Tick(object sender, EventArgs e)
        {
            if (lfg.Count == 0)
            {
                MatchGroups.Enabled = false;
            }
            else
            {
                List<LFG> l_MatchedGroup = new List<LFG>();
                List<LFG> l_NewGroup = new List<LFG>();

                for (int i = 0; i < lfg.Count; i++)
                {
                    LFG lae_CurGroup = lfg[i];
                    LFG l_OriCurGroup = lae_CurGroup;
                    List<string> l_MembersList = new List<string>();
                    List<string> l_ToMatchList = new List<string>();

                    if (!l_MatchedGroup.Contains(lae_CurGroup))
                    {
                        l_MatchedGroup.Add(lae_CurGroup);
                        foreach (LFG lae_GroupToMatch in lfg)
                        {
                            if (!l_MatchedGroup.Contains(lae_GroupToMatch))
                            {
                                l_MembersList = lae_CurGroup.Members.Split(',').Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
                                l_ToMatchList = lae_GroupToMatch.Members.Split(',').Where(x => !string.IsNullOrWhiteSpace(x)).ToList();

                                if (lae_CurGroup.HostRequest == lae_GroupToMatch.HostRequest
                                    && (l_MembersList.Count + l_ToMatchList.Count) <= lae_CurGroup.MNP)
                                {                                    
                                    l_MatchedGroup.Add(lae_GroupToMatch);
                                    lae_CurGroup.Members += lae_GroupToMatch.Members;                                    
                                }
                            }
                        }
                        l_NewGroup.Add(lae_CurGroup);
                        if (lae_CurGroup.Members != l_OriCurGroup.Members)
                        {
                            SharedGroupInfo(lae_CurGroup.Members, "", 1);
                            SetLobbyStart(lae_CurGroup);

                            l_MembersList = lae_CurGroup.Members.Split(',').Where(x => !string.IsNullOrWhiteSpace(x)).ToList();

                            if (l_MembersList.Count >= playerToStart)
                            {
                                bool l_IsFound = false;
                                int l_Index = 0;
                                ReadyGroups lae_ReadyGroup = new ReadyGroups();

                                foreach (string member in lae_CurGroup.Members.Split(new char[1] { ',' }))
                                {
                                    for (int j = 0; j < readyGroups.Count; j++)
                                    {
                                        lae_ReadyGroup = readyGroups[j];
                                        l_Index = j;
                                        if (lae_ReadyGroup.Group.Members.Contains(member))
                                        {
                                            l_IsFound = true;
                                            lae_ReadyGroup.Group = lae_CurGroup;
                                            break;
                                        }
                                    }
                                    break;
                                }
                                if (l_IsFound)
                                {
                                    readyGroups[l_Index] = lae_ReadyGroup;
                                    SetMatchCounter(lae_ReadyGroup.Group.Members, "Waiting For Match");
                                }
                                else
                                {
                                    lae_ReadyGroup.Group = lae_CurGroup;
                                    lae_ReadyGroup.Counter = DefaultTimerCount;
                                    readyGroups.Add(lae_ReadyGroup);
                                    SetMatchCounter(lae_ReadyGroup.Group.Members, "Waiting For Match");
                                    if (!GroupsReady.Enabled)
                                    {
                                        GroupsReady.Enabled = true;
                                    }
                                }
                            }
                        }                       
                    }
                }
                lfg = l_NewGroup;
                ETB_LFG.Text = lfg.Count.ToString();
            }
        }
        private void GroupsReady_Tick(object sender, EventArgs e)
        {
            if (readyGroups.Count == 0)
            {
                GroupsReady.Enabled = false;
            }
            else
            {
                for (int i = 0; i < readyGroups.Count; i++)
                {
                    ReadyGroups lae_ReadyGroup;
                    int l_Index = 0;

                    lae_ReadyGroup = readyGroups[i];
                    l_Index = i;
                    
                    if(lae_ReadyGroup.Counter == 0)
                    {
                        SetMatchCounter(lae_ReadyGroup.Group.Members, "Creating Instance");
                        readyGroups.RemoveAt(l_Index);
                        lfg.RemoveAt(l_Index);                        
                    }
                    else
                    {
                        lae_ReadyGroup.Counter -= 1;
                        if(lae_ReadyGroup.Counter < 0)
                        {
                            lae_ReadyGroup.Counter = 0;
                        }
                        readyGroups[l_Index] = lae_ReadyGroup;
                    }
                }
                ETB_Ready.Text = readyGroups.Count.ToString();
                ETB_LFG.Text = lfg.Count.ToString();
            }
        }
        private void CancelLFG(LFG l_LFG)
        {
            LFG lae_LFG = new LFG();
            ReadyGroups lae_ReadyGroup = new ReadyGroups();
            int l_Index = 0;
            bool l_IsFound = false;
            
            for (int i = 0; i < lfg.Count; i++)
            {
                lae_LFG = lfg[i];
                l_Index = i;

                if (lfg[i].Members.Contains(l_LFG.Requester))
                {
                    l_IsFound = true;
                    break;
                }
            }
            if(l_IsFound)
            {
                string members = lae_LFG.Members;

                List<string> l_MemberList = lae_LFG.Members.Split(',').Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
                List<string> l_TempList = l_MemberList;

                foreach (string member in l_LFG.Members.Split(new char[1] { ',' }))
                {
                    if(l_MemberList.Contains(member))
                    {
                        l_TempList.Remove(member);
                    }
                }

                members = String.Join(",", l_TempList);
                LFGAction(l_LFG, "Canceled");

                l_MemberList = members.Split(',').Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
                if (l_MemberList.Count > 0)
                {
                    lae_LFG.Members = members;
                    lfg[l_Index] = lae_LFG;
                    if (members != l_LFG.Members)
                    {
                        SharedGroupInfo(members, l_LFG.Members, 0);
                    }
                }
                else
                {
                    lfg.RemoveAt(l_Index);
                }
                l_IsFound = false;
            }

            for (int i = 0; i < readyGroups.Count; i++)
            {
                lae_ReadyGroup = readyGroups[i];
                l_Index = i;

                if (readyGroups[i].Group.Members.Contains(l_LFG.Requester))
                {
                    l_IsFound = true;
                    break;
                }
            }
            if (l_IsFound)
            {
                string members = lae_ReadyGroup.Group.Members;

                foreach (string member in l_LFG.Members.Split(new char[1] { ',' }))
                {
                    if (lae_ReadyGroup.Group.Members.Contains(member + ","))
                    {
                        members = members.Replace(member + ",", "");
                    }
                }
                List<string> l_ReadyMembersList = members.Split(',').Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
                if (l_ReadyMembersList.Count > 0)
                {
                    lae_ReadyGroup.Group.Members = members;
                    SetLobbyStart(lae_ReadyGroup.Group);
                    if (l_ReadyMembersList.Count >= playerToStart)
                    {
                        readyGroups[l_Index] = lae_ReadyGroup;
                    }
                    else
                    {
                        readyGroups.RemoveAt(l_Index);
                        SetMatchCounter(lae_ReadyGroup.Group.Members, "Finding Players...");
                    }
                }
                else
                {
                    readyGroups.RemoveAt(l_Index);
                }
            }
            ETB_LFG.Text = lfg.Count.ToString();
            ETB_Ready.Text = readyGroups.Count.ToString();
        }
        private void LFGAction(LFG l_LFG, string lfgAction)
        {
            string post = "Requester=" + l_LFG.Requester + "&Members=" + l_LFG.Members + "&LFGAction=" + lfgAction;
            string url = CMM_LFG;
            string method = "POST";
            string rc = "";

            rc = ProcessURL(url, method, post);

            ETB_Return.Text = rc;
        }
        private void SharedGroupInfo(string members, string leavers, int isJoining)
        {
            string post = "Members=" + members + "&Leavers=" + leavers + "&IsJoining=" + isJoining;
            string url = CMM_SharedGroupInfo;
            string method = "POST";
            string rc = "";
            
            rc = ProcessURL(url, method, post);

            ETB_Return.Text = rc;
        }
        private void SetMatchCounter(string members, string waitState)
        {
            string post = "Members=" + members + "&WaitState=" + waitState;
            string url = CMM_SetMatchCounter;
            string method = "POST";
            string rc = "";

            rc = ProcessURL(url, method, post);

            ETB_Return.Text = rc;
        }
        private void SetLobbyStart(LFG lfg)
        {
            switch (lfg.GameType)
            {
                case "DM":
                    playerToStart = 2;
                    DefaultTimerCount = 10;
                    break;
                case "KOTH":
                    playerToStart = 2;
                    DefaultTimerCount = 10;
                    break;
                case "CTF":
                    playerToStart = 2;
                    DefaultTimerCount = 10;
                    break;
                case "1L":
                    playerToStart = 2;
                    DefaultTimerCount = 10;
                    break;
                case "3L":
                    playerToStart = 2;
                    DefaultTimerCount = 10;
                    break;
                case "5L":
                    playerToStart = 2;
                    DefaultTimerCount = 10;
                    break;
                case "TA":
                    playerToStart = 4;
                    DefaultTimerCount = 10;
                    break;
                case "CCD":
                    playerToStart = 2;
                    DefaultTimerCount = 10;
                    break;
                case "BR":
                    playerToStart = 2;
                    DefaultTimerCount = 10;
                    break;
                default:
                    break;
            }
        }
        struct LFG
        {
            public string Requester;
            public string Members;
            public string HostRequest;
            public string GameType;
            public string TeamCount;
            public int MNP;
            public string IsCanceled;
        }
        struct ReadyGroups
        {
            public int Counter;
            public LFG Group;
        }
    }
}
