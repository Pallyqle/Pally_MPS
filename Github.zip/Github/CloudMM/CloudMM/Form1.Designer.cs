﻿namespace CloudMM
{
    partial class CloudMM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MatchGroups = new System.Windows.Forms.Timer(this.components);
            this.GroupsReady = new System.Windows.Forms.Timer(this.components);
            this.GetLFG = new System.Windows.Forms.Timer(this.components);
            this.ETB_Return = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.T_RPGPath = new System.Windows.Forms.Label();
            this.ETB_Ready = new System.Windows.Forms.TextBox();
            this.T_LobbyPath = new System.Windows.Forms.Label();
            this.ETB_LFG = new System.Windows.Forms.TextBox();
            this.ETB_Debug = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // MatchGroups
            // 
            this.MatchGroups.Interval = 3000;
            this.MatchGroups.Tick += new System.EventHandler(this.MatchGroups_Tick);
            // 
            // GroupsReady
            // 
            this.GroupsReady.Interval = 1000;
            this.GroupsReady.Tick += new System.EventHandler(this.GroupsReady_Tick);
            // 
            // GetLFG
            // 
            this.GetLFG.Enabled = true;
            this.GetLFG.Interval = 5000;
            this.GetLFG.Tick += new System.EventHandler(this.GetLFG_Tick);
            // 
            // ETB_Return
            // 
            this.ETB_Return.Location = new System.Drawing.Point(65, 77);
            this.ETB_Return.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.ETB_Return.Name = "ETB_Return";
            this.ETB_Return.ReadOnly = true;
            this.ETB_Return.Size = new System.Drawing.Size(505, 44);
            this.ETB_Return.TabIndex = 10000;
            this.ETB_Return.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(48, 48);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // T_RPGPath
            // 
            this.T_RPGPath.AutoSize = true;
            this.T_RPGPath.Location = new System.Drawing.Point(58, 233);
            this.T_RPGPath.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.T_RPGPath.Name = "T_RPGPath";
            this.T_RPGPath.Size = new System.Drawing.Size(107, 37);
            this.T_RPGPath.TabIndex = 10005;
            this.T_RPGPath.Text = "Ready";
            // 
            // ETB_Ready
            // 
            this.ETB_Ready.Location = new System.Drawing.Point(188, 224);
            this.ETB_Ready.Margin = new System.Windows.Forms.Padding(2);
            this.ETB_Ready.Name = "ETB_Ready";
            this.ETB_Ready.Size = new System.Drawing.Size(382, 44);
            this.ETB_Ready.TabIndex = 10003;
            // 
            // T_LobbyPath
            // 
            this.T_LobbyPath.AutoSize = true;
            this.T_LobbyPath.Location = new System.Drawing.Point(58, 166);
            this.T_LobbyPath.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.T_LobbyPath.Name = "T_LobbyPath";
            this.T_LobbyPath.Size = new System.Drawing.Size(80, 37);
            this.T_LobbyPath.TabIndex = 10004;
            this.T_LobbyPath.Text = "LFG";
            // 
            // ETB_LFG
            // 
            this.ETB_LFG.Location = new System.Drawing.Point(188, 157);
            this.ETB_LFG.Margin = new System.Windows.Forms.Padding(2);
            this.ETB_LFG.Name = "ETB_LFG";
            this.ETB_LFG.Size = new System.Drawing.Size(382, 44);
            this.ETB_LFG.TabIndex = 10002;
            // 
            // ETB_Debug
            // 
            this.ETB_Debug.Location = new System.Drawing.Point(65, 301);
            this.ETB_Debug.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.ETB_Debug.Name = "ETB_Debug";
            this.ETB_Debug.ReadOnly = true;
            this.ETB_Debug.Size = new System.Drawing.Size(505, 44);
            this.ETB_Debug.TabIndex = 10006;
            this.ETB_Debug.TabStop = false;
            // 
            // CloudMM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 402);
            this.Controls.Add(this.ETB_Debug);
            this.Controls.Add(this.T_RPGPath);
            this.Controls.Add(this.ETB_Ready);
            this.Controls.Add(this.T_LobbyPath);
            this.Controls.Add(this.ETB_LFG);
            this.Controls.Add(this.ETB_Return);
            this.Name = "CloudMM";
            this.Text = "Cloud Match Making";
            this.Load += new System.EventHandler(this.CloudMM_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer MatchGroups;
        private System.Windows.Forms.Timer GroupsReady;
        private System.Windows.Forms.Timer GetLFG;
        private System.Windows.Forms.TextBox ETB_Return;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label T_RPGPath;
        private System.Windows.Forms.TextBox ETB_Ready;
        private System.Windows.Forms.Label T_LobbyPath;
        private System.Windows.Forms.TextBox ETB_LFG;
        private System.Windows.Forms.TextBox ETB_Debug;
    }
}

