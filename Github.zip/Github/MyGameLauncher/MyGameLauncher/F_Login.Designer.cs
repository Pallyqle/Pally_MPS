﻿using System;

namespace MyGameLauncher
{
    partial class F_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.T_Username = new System.Windows.Forms.Label();
            this.ETB_Username = new System.Windows.Forms.TextBox();
            this.T_Password = new System.Windows.Forms.Label();
            this.ETB_Password = new System.Windows.Forms.TextBox();
            this.B_Register = new System.Windows.Forms.Button();
            this.PB_Download = new System.Windows.Forms.ProgressBar();
            this.T_DownloadPercent = new System.Windows.Forms.Label();
            this.B_PlayGame = new System.Windows.Forms.Button();
            this.T_Downloaded = new System.Windows.Forms.Label();
            this.T_Remaining = new System.Windows.Forms.Label();
            this.T_DownloadSpeed = new System.Windows.Forms.Label();
            this.T_RePassword = new System.Windows.Forms.Label();
            this.ETB_RePassword = new System.Windows.Forms.TextBox();
            this.B_Exit = new System.Windows.Forms.Button();
            this.I_GameImage = new System.Windows.Forms.PictureBox();
            this.T_Welcome = new System.Windows.Forms.Label();
            this.B_Login = new System.Windows.Forms.Button();
            this.CB_RemUsername = new System.Windows.Forms.CheckBox();
            this.CB_RemPassword = new System.Windows.Forms.CheckBox();
            this.B_Donate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.I_GameImage)).BeginInit();
            this.SuspendLayout();
            // 
            // T_Username
            // 
            this.T_Username.AutoSize = true;
            this.T_Username.ForeColor = System.Drawing.Color.Black;
            this.T_Username.Location = new System.Drawing.Point(26, 41);
            this.T_Username.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.T_Username.Name = "T_Username";
            this.T_Username.Size = new System.Drawing.Size(112, 24);
            this.T_Username.TabIndex = 0;
            this.T_Username.Text = "Username :";
            // 
            // ETB_Username
            // 
            this.ETB_Username.Location = new System.Drawing.Point(182, 38);
            this.ETB_Username.Name = "ETB_Username";
            this.ETB_Username.Size = new System.Drawing.Size(177, 32);
            this.ETB_Username.TabIndex = 1;
            // 
            // T_Password
            // 
            this.T_Password.AutoSize = true;
            this.T_Password.ForeColor = System.Drawing.Color.Black;
            this.T_Password.Location = new System.Drawing.Point(27, 86);
            this.T_Password.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.T_Password.Name = "T_Password";
            this.T_Password.Size = new System.Drawing.Size(113, 24);
            this.T_Password.TabIndex = 2;
            this.T_Password.Text = "Password : ";
            // 
            // ETB_Password
            // 
            this.ETB_Password.Location = new System.Drawing.Point(182, 83);
            this.ETB_Password.Name = "ETB_Password";
            this.ETB_Password.PasswordChar = '*';
            this.ETB_Password.Size = new System.Drawing.Size(177, 32);
            this.ETB_Password.TabIndex = 3;
            this.ETB_Password.UseSystemPasswordChar = true;
            // 
            // B_Register
            // 
            this.B_Register.BackColor = System.Drawing.Color.OrangeRed;
            this.B_Register.ForeColor = System.Drawing.Color.LawnGreen;
            this.B_Register.Location = new System.Drawing.Point(217, 131);
            this.B_Register.Name = "B_Register";
            this.B_Register.Size = new System.Drawing.Size(108, 42);
            this.B_Register.TabIndex = 5;
            this.B_Register.Text = "Register";
            this.B_Register.UseVisualStyleBackColor = false;
            this.B_Register.Click += new System.EventHandler(this.B_Register_Click);
            // 
            // PB_Download
            // 
            this.PB_Download.Location = new System.Drawing.Point(30, 380);
            this.PB_Download.Name = "PB_Download";
            this.PB_Download.Size = new System.Drawing.Size(581, 23);
            this.PB_Download.TabIndex = 6;
            // 
            // T_DownloadPercent
            // 
            this.T_DownloadPercent.AutoSize = true;
            this.T_DownloadPercent.Location = new System.Drawing.Point(26, 353);
            this.T_DownloadPercent.Name = "T_DownloadPercent";
            this.T_DownloadPercent.Size = new System.Drawing.Size(41, 24);
            this.T_DownloadPercent.TabIndex = 7;
            this.T_DownloadPercent.Text = "0%";
            this.T_DownloadPercent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.T_DownloadPercent.Visible = false;
            // 
            // B_PlayGame
            // 
            this.B_PlayGame.BackColor = System.Drawing.Color.OrangeRed;
            this.B_PlayGame.Enabled = false;
            this.B_PlayGame.ForeColor = System.Drawing.Color.LawnGreen;
            this.B_PlayGame.Location = new System.Drawing.Point(638, 370);
            this.B_PlayGame.Name = "B_PlayGame";
            this.B_PlayGame.Size = new System.Drawing.Size(194, 42);
            this.B_PlayGame.TabIndex = 8;
            this.B_PlayGame.Text = "Play Game";
            this.B_PlayGame.UseVisualStyleBackColor = false;
            this.B_PlayGame.Click += new System.EventHandler(this.B_PlayGame_Click);
            // 
            // T_Downloaded
            // 
            this.T_Downloaded.AutoSize = true;
            this.T_Downloaded.Location = new System.Drawing.Point(78, 353);
            this.T_Downloaded.Name = "T_Downloaded";
            this.T_Downloaded.Size = new System.Drawing.Size(121, 24);
            this.T_Downloaded.TabIndex = 9;
            this.T_Downloaded.Text = "Downloaded";
            this.T_Downloaded.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.T_Downloaded.Visible = false;
            // 
            // T_Remaining
            // 
            this.T_Remaining.AutoSize = true;
            this.T_Remaining.Location = new System.Drawing.Point(304, 353);
            this.T_Remaining.Name = "T_Remaining";
            this.T_Remaining.Size = new System.Drawing.Size(111, 24);
            this.T_Remaining.TabIndex = 10;
            this.T_Remaining.Text = "Remaining ";
            this.T_Remaining.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.T_Remaining.Visible = false;
            // 
            // T_DownloadSpeed
            // 
            this.T_DownloadSpeed.AutoSize = true;
            this.T_DownloadSpeed.Location = new System.Drawing.Point(515, 353);
            this.T_DownloadSpeed.Name = "T_DownloadSpeed";
            this.T_DownloadSpeed.Size = new System.Drawing.Size(74, 24);
            this.T_DownloadSpeed.TabIndex = 11;
            this.T_DownloadSpeed.Text = "0 MB/s";
            this.T_DownloadSpeed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.T_DownloadSpeed.Visible = false;
            // 
            // T_RePassword
            // 
            this.T_RePassword.AutoSize = true;
            this.T_RePassword.ForeColor = System.Drawing.Color.Black;
            this.T_RePassword.Location = new System.Drawing.Point(27, 131);
            this.T_RePassword.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.T_RePassword.Name = "T_RePassword";
            this.T_RePassword.Size = new System.Drawing.Size(145, 24);
            this.T_RePassword.TabIndex = 12;
            this.T_RePassword.Text = "Re-Password : ";
            this.T_RePassword.Visible = false;
            // 
            // ETB_RePassword
            // 
            this.ETB_RePassword.Location = new System.Drawing.Point(182, 128);
            this.ETB_RePassword.Name = "ETB_RePassword";
            this.ETB_RePassword.PasswordChar = '*';
            this.ETB_RePassword.Size = new System.Drawing.Size(177, 32);
            this.ETB_RePassword.TabIndex = 13;
            this.ETB_RePassword.UseSystemPasswordChar = true;
            this.ETB_RePassword.Visible = false;
            // 
            // B_Exit
            // 
            this.B_Exit.BackgroundImage = global::MyGameLauncher.Properties.Resources.XIcon;
            this.B_Exit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.B_Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_Exit.Location = new System.Drawing.Point(791, 0);
            this.B_Exit.Name = "B_Exit";
            this.B_Exit.Size = new System.Drawing.Size(41, 32);
            this.B_Exit.TabIndex = 15;
            this.B_Exit.UseVisualStyleBackColor = true;
            this.B_Exit.Click += new System.EventHandler(this.B_Exit_Click);
            // 
            // I_GameImage
            // 
            this.I_GameImage.BackColor = System.Drawing.SystemColors.Control;
            this.I_GameImage.BackgroundImage = global::MyGameLauncher.Properties.Resources.MyGame;
            this.I_GameImage.Location = new System.Drawing.Point(470, 38);
            this.I_GameImage.Name = "I_GameImage";
            this.I_GameImage.Size = new System.Drawing.Size(362, 211);
            this.I_GameImage.TabIndex = 14;
            this.I_GameImage.TabStop = false;
            // 
            // T_Welcome
            // 
            this.T_Welcome.AutoSize = true;
            this.T_Welcome.Location = new System.Drawing.Point(26, 38);
            this.T_Welcome.Name = "T_Welcome";
            this.T_Welcome.Size = new System.Drawing.Size(92, 24);
            this.T_Welcome.TabIndex = 16;
            this.T_Welcome.Text = "Welcome";
            this.T_Welcome.Visible = false;
            // 
            // B_Login
            // 
            this.B_Login.BackColor = System.Drawing.Color.OrangeRed;
            this.B_Login.ForeColor = System.Drawing.Color.LawnGreen;
            this.B_Login.Location = new System.Drawing.Point(30, 131);
            this.B_Login.Name = "B_Login";
            this.B_Login.Size = new System.Drawing.Size(108, 42);
            this.B_Login.TabIndex = 4;
            this.B_Login.Text = "Login";
            this.B_Login.UseVisualStyleBackColor = false;
            this.B_Login.Click += new System.EventHandler(this.B_Login_Click);
            // 
            // CB_RemUsername
            // 
            this.CB_RemUsername.AutoSize = true;
            this.CB_RemUsername.Location = new System.Drawing.Point(30, 180);
            this.CB_RemUsername.Name = "CB_RemUsername";
            this.CB_RemUsername.Size = new System.Drawing.Size(222, 28);
            this.CB_RemUsername.TabIndex = 17;
            this.CB_RemUsername.Text = "Remember Username";
            this.CB_RemUsername.UseVisualStyleBackColor = true;
            // 
            // CB_RemPassword
            // 
            this.CB_RemPassword.AutoSize = true;
            this.CB_RemPassword.Location = new System.Drawing.Point(31, 214);
            this.CB_RemPassword.Name = "CB_RemPassword";
            this.CB_RemPassword.Size = new System.Drawing.Size(218, 28);
            this.CB_RemPassword.TabIndex = 18;
            this.CB_RemPassword.Text = "Remember Password";
            this.CB_RemPassword.UseVisualStyleBackColor = true;
            // 
            // B_Donate
            // 
            this.B_Donate.BackColor = System.Drawing.Color.OrangeRed;
            this.B_Donate.ForeColor = System.Drawing.Color.LawnGreen;
            this.B_Donate.Location = new System.Drawing.Point(638, 322);
            this.B_Donate.Name = "B_Donate";
            this.B_Donate.Size = new System.Drawing.Size(194, 42);
            this.B_Donate.TabIndex = 19;
            this.B_Donate.Text = "Donate";
            this.B_Donate.UseVisualStyleBackColor = false;
            this.B_Donate.Click += new System.EventHandler(this.B_Donate_Click);
            // 
            // F_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.ClientSize = new System.Drawing.Size(844, 424);
            this.Controls.Add(this.B_Donate);
            this.Controls.Add(this.CB_RemPassword);
            this.Controls.Add(this.CB_RemUsername);
            this.Controls.Add(this.B_Register);
            this.Controls.Add(this.B_Login);
            this.Controls.Add(this.B_Exit);
            this.Controls.Add(this.I_GameImage);
            this.Controls.Add(this.T_DownloadSpeed);
            this.Controls.Add(this.T_Remaining);
            this.Controls.Add(this.T_Downloaded);
            this.Controls.Add(this.B_PlayGame);
            this.Controls.Add(this.T_DownloadPercent);
            this.Controls.Add(this.PB_Download);
            this.Controls.Add(this.ETB_Password);
            this.Controls.Add(this.T_Password);
            this.Controls.Add(this.ETB_Username);
            this.Controls.Add(this.ETB_RePassword);
            this.Controls.Add(this.T_RePassword);
            this.Controls.Add(this.T_Username);
            this.Controls.Add(this.T_Welcome);
            this.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.Name = "F_Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "My Game";
            this.Load += new System.EventHandler(this.F_Login_Load);
            ((System.ComponentModel.ISupportInitialize)(this.I_GameImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.Label T_Username;
        private System.Windows.Forms.TextBox ETB_Username;
        private System.Windows.Forms.Label T_Password;
        private System.Windows.Forms.TextBox ETB_Password;
        private System.Windows.Forms.Button B_Register;
        private System.Windows.Forms.ProgressBar PB_Download;
        private System.Windows.Forms.Label T_DownloadPercent;
        private System.Windows.Forms.Button B_PlayGame;
        private System.Windows.Forms.Label T_Downloaded;
        private System.Windows.Forms.Label T_Remaining;
        private System.Windows.Forms.Label T_DownloadSpeed;
        private System.Windows.Forms.Label T_RePassword;
        private System.Windows.Forms.TextBox ETB_RePassword;
        private System.Windows.Forms.PictureBox I_GameImage;
        private System.Windows.Forms.Button B_Exit;
        private System.Windows.Forms.Label T_Welcome;
        private System.Windows.Forms.Button B_Login;
        private System.Windows.Forms.CheckBox CB_RemUsername;
        private System.Windows.Forms.CheckBox CB_RemPassword;
        private System.Windows.Forms.Button B_Donate;
    }
}

