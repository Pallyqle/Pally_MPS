﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Xml;
using System.Xml.Linq;

namespace MyGameLauncher
{
    public partial class F_Login : Form
    {
        string login = "http://pallyqle.dx.am/LoginLauncher.php";
        string register = "http://pallyqle.dx.am/Register.php";
        string logout = "http://pallyqle.dx.am/LogOut.php";

        string[] Errors = 
        {
            "Lost Connection to Server",
            "User Does Not Exist",
            "Password Is Incorrect",
            "User Already Logged In",
            "Different IP Re-verification Sent",
            "Username Is Taken"
        };

        string[] Prompts =
        {
            "Please Verify Your Email",
            "Lost Connection to Server",
            "Logged In From Another Device",
            "User Already Logged In",
            "Please Re-Verify Your Account"
        };

        public F_Login()
        {
            InitializeComponent();
            Init_Remember();
        }

        WebClient client;
        Stopwatch sw = new Stopwatch();
        String updatedVersion = "";

        private void F_Login_Load(object sender, EventArgs e)
        {
            DownloadFile();
        }

        private void B_Register_Click(object sender, EventArgs e)
        {
            if(T_RePassword.Visible == false)
            {
                ETB_Username.Text = "";
                ETB_Password.Text = "";
                T_RePassword.Visible = true;
                ETB_RePassword.Visible = true;
                CB_RemUsername.Visible = false;
                CB_RemPassword.Visible = false;
                B_Login.Location = new Point(31, 188);
                B_Register.Location = new Point(217, 188);

            }
            else
            {
                Register();
            }
        }

        private void B_Login_Click(object sender, EventArgs e)
        {
            if(T_RePassword.Visible == true)
            {
                ETB_Username.Text = "";
                ETB_Password.Text = "";
                ETB_RePassword.Text = "";
                T_RePassword.Visible = false;
                ETB_RePassword.Visible = false;
                CB_RemUsername.Visible = true;
                CB_RemPassword.Visible = true;
                B_Login.Location = new Point(30, 131);
                B_Register.Location = new Point(217, 131);
            }
            else
            {
                Login();
            }

        }

        private void Login()
        {
            if (ETB_Username.Text == "" && ETB_Password.Text == "")
            {
                MessageBox.Show("Please Enter Your Infomation");
            }
            else if (ETB_Username.Text != "" && ETB_Password.Text == "")
            {
                MessageBox.Show("Please Enter Your Password");
            }
            else if (ETB_Username.Text == "" && ETB_Password.Text != "")
            {
                MessageBox.Show("Please Enter Your Username");
            }
            else 
            {
                string username = ETB_Username.Text;
                string password = ETB_Password.Text;
                string post = "Username=" + username + "&Password=" + password;
                string url = login;
                string method = "POST";
                string rc = "";

                rc = ProcessURL(url, method, post);

                if (!rc.Contains("Error"))
                {
                    if (!rc.Contains("Prompt"))
                    {
                        if (T_DownloadPercent.Text == "100%")
                        {
                            B_PlayGame.Enabled = true;
                        }

                        T_Welcome.Visible = true;
                        T_Welcome.Text = "Welcome, " + ETB_Username.Text;
                        T_Username.Visible = false;
                        T_Password.Visible = false;
                        ETB_Username.Visible = false;
                        ETB_Password.Visible = false;
                        B_Login.Visible = false;
                        B_Register.Visible = false;
                        CB_RemUsername.Visible = false;
                        CB_RemPassword.Visible = false;

                        StreamWriter loginInfo = new StreamWriter(Application.StartupPath + "/" + "LoginInfo.txt");
                        loginInfo.Write(ETB_Username.Text + "/" + ETB_Password.Text);
                        loginInfo.Close();
                    }
                    else
                    {
                        MessageBox.Show(rc.Replace("Prompt", ""));
                    }
                }
                else
                {
                    MessageBox.Show(rc.Replace("Error", ""));
                }
            }
           
        }

        private void Register()
        {
            if (ETB_Username.Text == "" && ETB_Password.Text == "" && ETB_RePassword.Text == "")
            {
                MessageBox.Show("Please Enter Your Infomation");
            }
            else if (ETB_Username.Text != "" && ETB_Password.Text == "" && ETB_RePassword.Text == "")
            {
                MessageBox.Show("Please Enter Desired Password");
            }
            else if (ETB_Username.Text == "" && (ETB_Password.Text != "" || ETB_RePassword.Text != ""))
            {
                MessageBox.Show("Please Enter Your Username");
            }
            else if (ETB_Password.Text != ETB_RePassword.Text)
            {
                MessageBox.Show("Password Did Not Match");
            }
            else if (ETB_Password.Text == ETB_RePassword.Text)
            {
                string username = ETB_Username.Text;
                string password = ETB_Password.Text;
                string post = "username=" + username + "&password=" + password;
                string url = "http://ue4gamelauncher.dx.am/Register.php";
                string method = "POST";
                string rc = "";

                rc = ProcessURL(url, method, post);

                MessageBox.Show(rc);
            }

        }

        private void DownloadFile()
        {
            string url = "";
            string xmlUrl = "http://ue4gamelauncher.dx.am/Update.xml";

            Version newVersion = null;
            Version currentVersion = null;
            XmlTextReader newReader = null;
            XmlTextReader currentReader = null;
            string elementName = "";
            string currentElementName = "";

            newReader = new XmlTextReader(xmlUrl);
            newReader.MoveToContent();

            if((newReader.NodeType == XmlNodeType.Element) && (newReader.Name == "MyGame"))
            {
                while(newReader.Read() && newReader != null)
                {
                    if(newReader.NodeType == XmlNodeType.Element)
                    {
                        elementName = newReader.Name;
                    }
                    else
                    {
                        if((newReader.NodeType == XmlNodeType.Text) && (newReader.HasValue))
                        {
                            switch(elementName)
                            {
                                case "version":
                                    newVersion = new Version(newReader.Value);
                                    break;
                                case "url":
                                    url = (newReader.Value);
                                    break;
                            }
                        }
                    }
                }
            }


            currentReader = new XmlTextReader(Application.StartupPath + "/" + "Update.xml");
            currentReader.MoveToContent();

            if ((currentReader.NodeType == XmlNodeType.Element) && (currentReader.Name == "MyGame"))
            {
                while (currentReader.Read())
                {
                    if (currentReader.NodeType == XmlNodeType.Element)
                    {
                        currentElementName = currentReader.Name;
                    }
                    else
                    {
                        if ((currentReader.NodeType == XmlNodeType.Text) && (currentReader.HasValue))
                        {
                            switch (currentElementName)
                            {
                                case "version":
                                    currentVersion = new Version(currentReader.Value);
                                    break;
                            }
                            currentReader.Close();
                        }
                    }
                }
            }


            if (currentVersion.CompareTo(newVersion) < 0)
            {
                using (client = new WebClient())
                {
                    client.DownloadFileCompleted += new AsyncCompletedEventHandler(DownloadCompleted);
                    client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(DownloadProgressChanged);

                    Uri uri = new Uri(url);
                    string fileName = System.IO.Path.GetFileName(uri.AbsolutePath);
                    client.DownloadFileAsync(uri, Application.StartupPath + "/GameLauncher/Content/Paks/" + fileName);

                    updatedVersion = newVersion.ToString();

                    T_DownloadPercent.Visible = true;
                    T_Downloaded.Visible = true;
                    T_Remaining.Visible = true;
                    T_DownloadSpeed.Visible = true;

                    sw.Start();
                }
            }
            else
            {
                T_DownloadPercent.Visible = true;
                T_DownloadPercent.Text = "100%";
                PB_Download.Value = 100;
            }
           
        }

        private void DownloadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            T_Downloaded.Visible = false;
            T_Remaining.Visible = false;
            T_DownloadSpeed.Visible = false;

            if(T_Welcome.Visible == true)
            {
                B_PlayGame.Enabled = true;
            }

            XmlDocument update = new XmlDocument();
            update.Load(Application.StartupPath + "/" + "Update.xml");
            update.SelectSingleNode("MyGame/version").InnerText = updatedVersion;
            update.Save(Application.StartupPath + "/" + "Update.xml");

        }

        private void DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
           
            T_DownloadPercent.Text = e.ProgressPercentage.ToString() + "%";
            T_Downloaded.Text = "Downloaded " + string.Format("{0} MB", (e.BytesReceived / 1048576d).ToString("0.00"));
            T_Remaining.Text = "Remaining " + string.Format("{0} MB", ((e.TotalBytesToReceive - e.BytesReceived) / 1048576d).ToString("0.00"));
            T_DownloadSpeed.Text = string.Format("{0} MB/s", (e.BytesReceived / 1048576d / sw.Elapsed.TotalSeconds).ToString("0.00"));
            PB_Download.Value = e.ProgressPercentage;
        }

        private void B_Exit_Click(object sender, EventArgs e)
        {
            if(T_Welcome.Visible == true)
            {
                string username = ETB_Username.Text;
                string post = "username=" + username;
                string url = "http://ue4gamelauncher.dx.am/Logoff.php";
                string method = "POST";
                string rc = "";

                rc = ProcessURL(url, method, post);
            }

            File.Delete(Application.StartupPath + "/" + "LoginInfo.txt");

            Save_Remember();

            this.Close();
        }

        private void B_PlayGame_Click(object sender, EventArgs e)
        {
            Process.Start(Application.StartupPath + "/" + "Pally_MPS.exe");
            this.Close();
        }

        private string ProcessURL(string url, string method , string post)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] data = encoding.GetBytes(post);
            string rc = "";
            WebRequest request = WebRequest.Create(url);
            if (post != "")
            {
                request.Method = method;
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = data.Length;

                Stream stream = request.GetRequestStream();
                stream.Write(data, 0, data.Length);
                stream.Close();

                WebResponse response = request.GetResponse();
                stream = response.GetResponseStream();

                StreamReader sr = new StreamReader(stream);
                rc = sr.ReadToEnd();
            }
            else
            {
                WebResponse response = request.GetResponse();
                StreamReader sr = new StreamReader(response.GetResponseStream());
                rc = sr.ReadToEnd();
            }
            return rc;
        }

        private void Init_Remember()
        {
            if(Properties.Settings.Default.RemUsername == true)
            {
                ETB_Username.Text = Properties.Settings.Default.Username;
                CB_RemUsername.Checked = true;
            } 
            if(Properties.Settings.Default.RemPassword == true)
            {
                ETB_Password.Text = Properties.Settings.Default.Password;
                CB_RemPassword.Checked = true;
            }                  
        }

        private void Save_Remember()
        {
            if(CB_RemUsername.Checked == true)
            {
                Properties.Settings.Default.Username = ETB_Username.Text;
                Properties.Settings.Default.RemUsername = true;
                Properties.Settings.Default.Save();

                if (CB_RemPassword.Checked == true)
                {
                    Properties.Settings.Default.Password = ETB_Password.Text;
                    Properties.Settings.Default.RemPassword = true;
                    Properties.Settings.Default.Save();
                }
                else if (CB_RemPassword.Checked == false)
                {
                    Properties.Settings.Default.Password = "";
                    Properties.Settings.Default.RemPassword = false;
                    Properties.Settings.Default.Save();
                }
            }
            else 
            {
                Properties.Settings.Default.Username = "";
                Properties.Settings.Default.RemUsername = false;
                Properties.Settings.Default.Save();

                if (CB_RemPassword.Checked == true)
                {
                    Properties.Settings.Default.Password = ETB_Password.Text;
                    Properties.Settings.Default.RemPassword = true;
                    Properties.Settings.Default.Save();
                }
                else if (CB_RemPassword.Checked == false)
                {
                    Properties.Settings.Default.Password = "";
                    Properties.Settings.Default.RemPassword = false;
                    Properties.Settings.Default.Save();
                }
            }
        }

        private void B_Donate_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://pallyqle.blogspot.com");
        }
    }
}
