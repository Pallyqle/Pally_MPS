﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Xml;
using System.Xml.Linq;

namespace DSManager
{
    public partial class DS_RegionManager : Form
    {
        string getHostRequestURL = "http://pallyqle.dx.am/DS_GetHostRequest.php";
        string postHostRequestURL = "http://pallyqle.dx.am/DS_PostHostRequest.php";
        string resetServerURL = "http://pallyqle.dx.am/DS_ResetServers.php";

        public DS_RegionManager()
        {
            InitializeComponent();
        }
        private void DSManager_Load(object sender, EventArgs e)
        {
            InitializeSQL();            
        }
        private void InitializeSQL()
        {
            
        }
        private void CheckCreateRequest()
        {
            if (CB_DSRegion.SelectedItem != null)
            {
                string post = "Region=" + CB_DSRegion.SelectedItem.ToString();
                string url = getHostRequestURL;
                string method = "POST";
                string rc = "";

                rc = ProcessURL(url, method, post);

                if (rc == "Error0")
                {
                    ETB_Return.Text = "Connection Failed";
                }
                else if (rc == "")
                {
                    ETB_Return.Text = "Checking Creation Request";
                }
                else
                {
                    ETB_Return.Text = rc;
                    string[] rcp = rc.Split(new char[1] { ';' });
                    StartServer(rcp);
                }
            }
        }
        private void CreateServer()
        {
            if (CB_PathExtension.SelectedItem != null)
            { 
                if(File.Exists(@ETB_LobbyPath.Text + CB_PathExtension.SelectedItem.ToString())
                && File.Exists(@ETB_RPGPath.Text + CB_PathExtension.SelectedItem.ToString())
                && File.Exists(@ETB_PGPath.Text + CB_PathExtension.SelectedItem.ToString()))
                {
                    string post = "Hosts=" + ETB_ServerName.Text + "&Name=" + ETB_ServerName.Text + 
                                    "&Region=" + CB_Region.SelectedItem.ToString() + "&MNP=" + Num_MNP.Value +
                                    "&ServerType=" + CB_ServerType.SelectedItem.ToString();
                    string url = postHostRequestURL;
                    string method = "POST";
                    string rc = "";

                    rc = ProcessURL(url, method, post);
                    string[] rcp = new string[1] { CB_ServerType.SelectedItem.ToString() };

                    if (rc == "Game Posted")
                    {
                        StartServer(rcp);
                        ETB_Return.Text = rc;
                        B_CreateServer.Enabled = true;
                    }
                    else if (rc == "Server Name Taken")
                    {
                        B_CreateServer.Enabled = true;
                        DisplayError(rc);
                    }
                }
                else
                {
                    DisplayError("One or More Path is Invalid");
                    B_CreateServer.Enabled = true;
                }
            }
            else
            {
                DisplayError("Invalid Extension");
                B_CreateServer.Enabled = true;
            }
        }
        private void StartServer(string[] serverList)
        {
            foreach (string a in serverList)
            {
                switch (a)
                {
                    case "Lobby":
                        System.Diagnostics.Process.Start(
                            System.Environment.ExpandEnvironmentVariables(@ETB_LobbyPath.Text));
                        break;
                    case "RPG":
                        System.Diagnostics.Process.Start(
                            System.Environment.ExpandEnvironmentVariables(@ETB_RPGPath.Text));
                        break;
                    case "GI":
                        System.Diagnostics.Process.Start(
                             System.Environment.ExpandEnvironmentVariables(@ETB_PGPath.Text));
                        break;
                    default:
                        break;
                }
            }
        }
        private void ResetServerDB()
        {
            string IsStarted = "1";
            string post = "IsStarted=" + IsStarted;
            string url = resetServerURL;
            string method = "POST";
            string rc = "";

            rc = ProcessURL(url, method, post);

            ETB_Return.Text = rc;
        }
        private string ProcessURL(string url, string method, string post)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] data = encoding.GetBytes(post);
            string rc = "";
            WebRequest request = WebRequest.Create(url);

            request.Method = method;
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;

            try
            {
                Stream stream = request.GetRequestStream();
                stream.Write(data, 0, data.Length);
                stream.Close();

                WebResponse response = request.GetResponse();
                stream = response.GetResponseStream();

                StreamReader sr = new StreamReader(stream);
                rc = sr.ReadToEnd();
            }
            catch (WebException e)
            {
                if(!B_CreateServer.Enabled)
                {
                    B_CreateServer.Enabled = true;
                }
                ETB_Return.Text = "Connection Error";
            }

            return rc;
        }
        private void DisplayError(string errorMsg)
        {
            DialogResult result;
            MessageBoxButtons buttons = MessageBoxButtons.OK;
            result = MessageBox.Show(errorMsg, "Error", buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            CheckCreateRequest();
        }
        private void DSManager_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }
        private void B_StartDS_Click(object sender, EventArgs e)
        {
            if (CB_DSRegion.SelectedItem != null)
            {
                if (CB_PathExtension.SelectedItem != null)
                {
                    if (ETB_LobbyPath.Text != "" && ETB_RPGPath.Text != "" && ETB_PGPath.Text != "")
                    {
                        if (File.Exists(@ETB_LobbyPath.Text + CB_PathExtension.SelectedItem.ToString())
                        && File.Exists(@ETB_RPGPath.Text + CB_PathExtension.SelectedItem.ToString())
                        && File.Exists(@ETB_PGPath.Text + CB_PathExtension.SelectedItem.ToString()))
                        {                            
                            timer1.Enabled = !timer1.Enabled;
                            if (timer1.Enabled)
                            {
                                B_StartDS.Text = "Stop";
                                CheckCreateRequest();
                            }                                
                            else
                            {
                                B_StartDS.Text = "Start";
                                ETB_Return.Text = "";
                            }                                
                        }
                        else
                            DisplayError("One or More Path is not Valid");
                    }
                    else
                        DisplayError("Missing Path Information");
                }
                else
                    DisplayError("Missing File Extention");
            }
            else
                DisplayError("Missing Region");
        }
        private void B_CreateServer_Click(object sender, EventArgs e)
        {
            if (CB_ServerType.SelectedItem != null && CB_Region.SelectedItem != null
                && ETB_ServerName.Text != "" && Num_MNP.ToString() != "")
            {
                ETB_Return.Text = "";
                B_CreateServer.Enabled = false;
                CreateServer();
            }
            else
                DisplayError("Missing Server Information");
        }
        private void B_ResetDatabase_Click(object sender, EventArgs e)
        {
            ResetServerDB();
        }

        private void B_Default_Click(object sender, EventArgs e)
        {
            ETB_LobbyPath.Text = AppDomain.CurrentDomain.BaseDirectory + "Lobby";
            ETB_RPGPath.Text = AppDomain.CurrentDomain.BaseDirectory + "RPG";
            ETB_PGPath.Text = AppDomain.CurrentDomain.BaseDirectory + "PG";
            CB_PathExtension.SelectedItem = CB_PathExtension.Items[0];
            CB_DSRegion.SelectedItem = CB_Region.Items[0];
            CB_ServerType.SelectedItem = CB_ServerType.Items[0];
            CB_Region.SelectedItem = CB_Region.Items[0];
            ETB_ServerName.Text = "Official";
            Num_MNP.Value = 32;
        }
    }
}
