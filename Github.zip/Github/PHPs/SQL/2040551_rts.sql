-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: pdb43.awardspace.net
-- Generation Time: Nov 05, 2020 at 11:31 PM
-- Server version: 5.7.20-log
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2040551_rts`
--

-- --------------------------------------------------------

--
-- Table structure for table `DS_CreationRequest`
--

CREATE TABLE `DS_CreationRequest` (
  `RequestIndex` int(255) NOT NULL,
  `Region` varchar(1000) NOT NULL,
  `ServerType` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `DS_HostInfo`
--

CREATE TABLE `DS_HostInfo` (
  `Hosts` varchar(1000) NOT NULL,
  `ServerType` varchar(1000) NOT NULL,
  `Name` varchar(1000) NOT NULL,
  `Password` varchar(1000) NOT NULL,
  `Region` varchar(1000) NOT NULL,
  `MNP` int(255) NOT NULL,
  `PG` varchar(1000) NOT NULL,
  `IG` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LFG`
--

CREATE TABLE `LFG` (
  `ID` int(20) NOT NULL,
  `Requester` varchar(1000) NOT NULL,
  `Members` varchar(1000) NOT NULL,
  `HostRequest` varchar(1000) NOT NULL,
  `GameType` varchar(1000) NOT NULL,
  `TeamCount` varchar(1000) NOT NULL,
  `MNP` int(20) NOT NULL DEFAULT '0',
  `IsCanceled` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `MOBA_HeroList`
--

CREATE TABLE `MOBA_HeroList` (
  `Name` varchar(1000) NOT NULL,
  `IsAvailable` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MOBA_HeroList`
--

INSERT INTO `MOBA_HeroList` (`Name`, `IsAvailable`) VALUES
('Hero0', 1),
('Hero1', 1),
('Hero2', 1),
('Hero3', 1),
('Hero4', 1),
('Hero5', 1),
('Hero6', 1),
('Hero7', 1),
('Hero8', 1),
('Hero9', 1),
('Hero10', 1),
('Hero11', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Servers`
--

CREATE TABLE `Servers` (
  `ID` int(255) NOT NULL,
  `ServerType` varchar(20) NOT NULL,
  `IP` varchar(20) NOT NULL,
  `Port` int(255) NOT NULL,
  `Hosts` varchar(1000) NOT NULL,
  `Name` varchar(1000) NOT NULL,
  `Password` varchar(1000) NOT NULL,
  `Region` varchar(1000) NOT NULL,
  `IsInGame` tinyint(1) NOT NULL,
  `CNP` int(10) NOT NULL,
  `MNP` int(10) NOT NULL,
  `PG` varchar(1000) NOT NULL,
  `IG` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Servers`
--

INSERT INTO `Servers` (`ID`, `ServerType`, `IP`, `Port`, `Hosts`, `Name`, `Password`, `Region`, `IsInGame`, `CNP`, `MNP`, `PG`, `IG`) VALUES
(1, 'RPG', '75.84.244.243', 7777, '', 'Official 1', '', 'North America', 0, 0, 32, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `Users_Char`
--

CREATE TABLE `Users_Char` (
  `UserID` int(20) NOT NULL,
  `Server` varchar(1000) NOT NULL,
  `Name` varchar(1000) NOT NULL,
  `Affiliation` varchar(1000) NOT NULL,
  `XP` varchar(1000) NOT NULL,
  `Status` varchar(1000) NOT NULL,
  `Inv` varchar(1000) NOT NULL,
  `Equips` varchar(1000) NOT NULL,
  `Skills` varchar(1000) NOT NULL,
  `Talents` varchar(1000) NOT NULL,
  `Appearance` varchar(1000) NOT NULL,
  `Gameplay` varchar(1000) NOT NULL,
  `Keybinds` varchar(1000) NOT NULL,
  `KeyRemap` varchar(1000) NOT NULL,
  `Chat` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users_Char`
--

INSERT INTO `Users_Char` (`UserID`, `Server`, `Name`, `Affiliation`, `XP`, `Status`, `Inv`, `Equips`, `Skills`, `Talents`, `Appearance`, `Gameplay`, `Keybinds`, `KeyRemap`, `Chat`) VALUES
(1, 'RPG|Official 1|75.84.244.243:7777', 'test', 'Species0|Class0|Faction0', '1:0.0|1:0.0|', '490.0:485.0:91.0:0.0:339.785156:212.893066|', '', '', '', '', '1.0:0.027451:0.0:1.0|1.0|', '', '', '', 'All:0:0:0:0:0:0:0:0:0:0|Whisper:0:0:0:0:0:0:0:0:0:0|'),
(2, 'RPG|Official 1|75.84.244.243:7777', 'hrfhf', 'Species0|Class0|Faction0', '1:0.0|1:0.0|', '0.0:0.0:0.0:0.0:0.0:0.0|', '', '', '', '', '1.0:0.027451:0.0:1.0|1.0|', '', '', '', ''),
(3, 'RPG|Official 1|46.32.48.191:7777', 'test3', 'Species0|Class2|Faction0', '1:0.0|1:0.0|', '199.0:-174.0:47.0:0.0:344.355469:159.708252|', '', '', '', '', '1.0:0.187226:0.027282:1.0|0.5|', '', '', '', ''),
(4, 'RPG|Official 1|75.84.244.243:7777', 'test1', 'Species2|Class6|Faction1', '1:0.0|1:0.0|', '-63.0:-499.0:76.0:0.0:333.627319:40.940552|', '', '', '', '', '0.0:1.0:0.686669:1.0|0.833289|', '', '', '', 'All:0:0:0:0:1:0:1:1:1:1|Group:0:0:0:0:0:0:0:1:0:1|Wisper:0:0:0:0:0:0:0:0:1:0|'),
(1, '', 'testy', 'Species0|Class0|Faction0', '1:0.0|1:0.0|', '0.0:0.0:0.0:0.0:0.0:0.0|', '', '', '', '', '1.0:0.027451:0.0:1.0|1.0|', '', '', '', ''),
(2, 'RPG|Official 1|75.84.244.243:7777', 'yese', 'Species0|Class0|Faction0', '1:0.0|1:0.0|', '73.0:-424.0:135.0:0.0:343.460083:129.473877|', '', '', '', '', '1.0:0.187226:0.027282:1.0|1.5|', '', '', '', 'All:0:0:0:0:1:0:1:1:1:1|Group:0:0:0:0:0:0:0:1:0:1|Wisper:0:0:0:0:0:0:0:0:1:0|'),
(5, 'RPG|Official 1|46.32.48.191:7777', 'tgggr', 'Species4|Class1|Faction2', '1:0.0|1:0.0|', '-590.0:147.0:55.0:0.0:338.598633:324.223022|', '', '', '', '', '0.802083:0.446822:0.690685:1.0|0.6|', '', '', '', 'All:0:0:1:0:1:1:1:1:1:1|Group:0:0:0:0:0:1:0:1:1:0|Wisper:0:0:0:0:0:0:1:0:0:0|');

-- --------------------------------------------------------

--
-- Table structure for table `Users_Play`
--

CREATE TABLE `Users_Play` (
  `UserID` int(20) NOT NULL,
  `Username` varchar(1000) NOT NULL,
  `IsLogin` tinyint(1) NOT NULL,
  `MainIP` varchar(1000) NOT NULL,
  `InstanceIP` varchar(1000) NOT NULL,
  `PotentialGI` varchar(1000) NOT NULL,
  `Alert` varchar(1000) NOT NULL,
  `CurrentChar` varchar(1000) NOT NULL,
  `CurrentParty` varchar(1000) NOT NULL,
  `Leader` varchar(1000) NOT NULL,
  `XServerMessages` varchar(1000) NOT NULL,
  `GIReady` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users_Play`
--

INSERT INTO `Users_Play` (`UserID`, `Username`, `IsLogin`, `MainIP`, `InstanceIP`, `PotentialGI`, `Alert`, `CurrentChar`, `CurrentParty`, `Leader`, `XServerMessages`, `GIReady`) VALUES
(3, 'Gerok', 0, '', '', '', '', 'test3', '', '', '', ''),
(5, 'pallyqle#Steam', 0, '', '', '', '', 'tgggr', '', '', '', ''),
(4, 'pallyqle', 0, '', '', '', '', 'test1', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `Users_Save`
--

CREATE TABLE `Users_Save` (
  `UserID` int(20) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Email` varchar(1000) NOT NULL,
  `Verification` varchar(1000) NOT NULL,
  `BanTime` int(10) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `PrevIP` varchar(1000) NOT NULL,
  `PrevLogin` varchar(1000) NOT NULL,
  `PrevDevice` varchar(1000) NOT NULL,
  `FavServers` varchar(1000) NOT NULL,
  `CharLimit` int(255) NOT NULL,
  `FriendList` varchar(1000) NOT NULL,
  `BlockedList` varchar(1000) NOT NULL,
  `Privacy` varchar(1000) NOT NULL,
  `BankInv` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users_Save`
--

INSERT INTO `Users_Save` (`UserID`, `Username`, `Email`, `Verification`, `BanTime`, `Password`, `PrevIP`, `PrevLogin`, `PrevDevice`, `FavServers`, `CharLimit`, `FriendList`, `BlockedList`, `Privacy`, `BankInv`) VALUES
(4, 'pallyqle', 'pallyqle@gmail.com', '1', 0, 'a', '75.84.244.243', '2020|11|3|20|35|18', 'DESKTOP-MDGP6VJ', '', 4, '', '', '', ''),
(3, 'gerok', 'gerok@gmail.com', '1', 0, 'a', '75.84.244.243', '2020|11|3|20|14|7', 'localhost-00055', '', 4, '', '', '', ''),
(5, 'pallyqle#Steam', '', '1', 0, '', '75.84.244.243', '2020|11|3|20|14|16', '76561198199241774', '', 4, '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `DS_CreationRequest`
--
ALTER TABLE `DS_CreationRequest`
  ADD PRIMARY KEY (`RequestIndex`);

--
-- Indexes for table `DS_HostInfo`
--
ALTER TABLE `DS_HostInfo`
  ADD PRIMARY KEY (`Hosts`);

--
-- Indexes for table `LFG`
--
ALTER TABLE `LFG`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `MOBA_HeroList`
--
ALTER TABLE `MOBA_HeroList`
  ADD PRIMARY KEY (`Name`);

--
-- Indexes for table `Servers`
--
ALTER TABLE `Servers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Users_Char`
--
ALTER TABLE `Users_Char`
  ADD PRIMARY KEY (`Name`);

--
-- Indexes for table `Users_Play`
--
ALTER TABLE `Users_Play`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `Users_Save`
--
ALTER TABLE `Users_Save`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `DS_CreationRequest`
--
ALTER TABLE `DS_CreationRequest`
  MODIFY `RequestIndex` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `LFG`
--
ALTER TABLE `LFG`
  MODIFY `ID` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Servers`
--
ALTER TABLE `Servers`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Users_Save`
--
ALTER TABLE `Users_Save`
  MODIFY `UserID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
