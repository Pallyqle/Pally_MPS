<?php

require './src/DBInfo.php';

        $Return = "";
	$Name = $_REQUEST["Name"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT CNP FROM Servers WHERE `Name` = '".$Name."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                        $row = mysqli_fetch_assoc($result);
                        
                        $Difference = $row['CNP'] - 1;
                        if($Difference >= 0)
                        {
                                $sql = "UPDATE `Servers` SET `CNP` = '".$Difference."' WHERE `Name` = '".$Name."'";
                                mysqli_query($con, $sql);
                                
                                $Return = "Player Subtracted";  
                        }
                }
                echo "{Content: \"".$Return."\"}"; 
        }

?>