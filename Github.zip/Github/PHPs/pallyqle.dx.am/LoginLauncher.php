<?php

	require './src/DBInfo.php';

	$Return = "";
        
	$Username = $_REQUEST["Username"];
	$Password = $_REQUEST["Password"];
        	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{                
		$sql = "SELECT * FROM Users_Save  WHERE `Username` = '".$Username."' OR `Email` = '".$Username."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{		
				
			$Return = $row['UserID']."/".$row['Username'];
		}
		else
		{
			$Return = "Error1";   
		}
	}
	echo $Return; 
?>