<?php

	require './src/DBInfo.php';
	
	$Return = "";
	$IP = $_REQUEST["IP"];
	$Port = $_REQUEST["Port"];
        
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName); 
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "DELETE FROM Servers WHERE `IP` = '".$IP."' && `Port` = '".$Port."'";
		mysqli_query($con, $sql);
	}
	echo $Return; 
	
?>