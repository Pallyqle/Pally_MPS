<?php
        
	require './src/DBInfo.php';
	
	$Return = "";
        
	$FullIP = $_REQUEST["FullIP"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);   	
	if ($con->connect_errno) 
	{
			$Return = "Error0";
			exit();
			$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Play";// WHERE `MainIP` = '".$FullIP."' OR `InstanceIP` = '".$FullIP."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				if($row['Alert'] != "")
				{
					$Return .= $row['Username']. "/" .$row['Alert']. ";";
					$sql = "UPDATE `Users_Play` SET `Alert` = '' WHERE `Username` = '".$row['Username']."'";
					mysqli_query($con, $sql);					
				}
			}		
		}      
		else
		{
			$Return = "Success10";
		}
	}	
	echo $Return;
?>