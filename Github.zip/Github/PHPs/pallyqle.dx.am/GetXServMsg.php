<?php

require './src/DBInfo.php';

        $Return = "";
	$Username = $_REQUEST["Username"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users WHERE `Username` = '".$Username."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql);
                
                $Return $row['XServerMessages'];
                echo "{Content: \"".$Return."\"}"; 
                
                $sql = "UPDATE `Users` SET `XServerMessages` = '' WHERE `Username` = '".$Username."'";
                mysqli_query($con, $sql);
        }

?>