<?php

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require './src/Exception.php';
	require './src/PHPMailer.php';
	require './src/SMTP.php';
	require './src/DBInfo.php';
			
	$Return = "";
        
	$Username = $_REQUEST["Username"];
	$Email = $_REQUEST["Email"];
	$Password = $_REQUEST["Password"];
	$Verification = bin2hex(random_bytes(8));     

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Save WHERE `Username` = '".$Username."' OR `Email` = '".$Email."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			$row = mysqli_fetch_assoc($result);
			if($row['Username'] == $Username)
			{
				$Return = "Error5";
			}
			else
			{
				$Return = "Error20";
			}
		}
		// Create the user save
		// Prompt user to check their email
		else
		{
			// Check if email has valid format and domain			
			if (!filter_var($Email, FILTER_VALIDATE_EMAIL) || !checkdnsrr(substr(strrchr($Email, "@"), 1))) 
			{
				$Return = "Error18";
			}
			// Send verification to the address	
			else
			{
				// Create user after checking email format and domaain
				$sql = "INSERT INTO `Users_Save` (`UserID`, `Username`, `Email`, `Verification`, `Password`, `PrevIP`, `PrevLogin`, `FavServers`, `CharLimit`, `FriendList`, `BlockedList`, `BankInv`) 
				VALUES (Null, '".$Username."', '".$Email."', '".$Verification."', '".$Password."', '', '', '', '4', '', '', '')";
				
				mysqli_query($con, $sql); 				
				
				$sql = "SELECT * FROM Users_Save  WHERE `Username` = '".$Username."'";
				$result = mysqli_query($con, $sql);  
				
				if(mysqli_num_rows($result) > 0)
				{
					$row = mysqli_fetch_assoc($result);
					
					$mail = new PHPMailer(true);

					$mail->SMTPDebug = 0;

					$mail->Host = "smtp.mboxhosting.com";
					$mail->SMTPAuth = true;
					$mail->Username = $DBEmail;
					$mail->Password = $DBPassword;
					$mail->SMTPSecure = "tls";
					$mail->Port = 465;
					$mail->setFrom("noreply@pallyqle.dx.am", "Pallyqle");
					$mail->addAddress($Email);
					$mail->isHTML(true);    
					$mail->Subject = "Email Verification Test";
					$mail->Body = '<h1> Thank you for trying my multiplayer system. </h1>
									<p> Click the link to verify your account: 
									<br> http://www.pallyqle.dx.am/Verification.php?Email='.$Email.'&Verification='.$row['Verification'].'
									</p>
					';      
					try 
					{
						$mail->send();	
						$Return = "Prompt0";
					} 
					catch (Exception $e) 
					{
						$Return = "Error17";				
					}
				}
				// Fail to create an account
				else
				{
					$Return = "Error15"; 
				}
			}			
		}
	}     
	echo $Return; 
?>