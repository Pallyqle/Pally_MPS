<?php

require './src/DBInfo.php';

	$Username = $_POST["Username"];
	$Password = $_POST["Password"];
        $UserIP = $_POST["UserIP"];       
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	$sql = "SELECT * FROM Users WHERE `Username` = '".$Username."' AND `Password` = '".$Password."'";
	$result = mysqli_query($con, $sql);
	if(mysqli_num_rows($result) > 0)
	{
                $row = mysqli_fetch_assoc($result);
                
                if($row['IsLogin'] == 0)
                {
                        
                        //if($row['UserIP'] == $IP || $row['UserIP'] == "")
                        //{
                                $sql = "UPDATE `Users` SET `IsLogin` = '1', `UserIP` = '".$UserIP."', `Alert` = '', `GIReady` = ''
                                WHERE `Username` = '".$Username."'";
                                mysqli_query($con, $sql);                                        
                                echo "Login Success";
                                $FriendList = explode("|", $row['FriendList']);
                                foreach($FriendList as $x)
                                {
                                        $sql = "SELECT Alert, IsLogin FROM Users WHERE `Username` = '".$x."'";
                                        $result = mysqli_query($con, $sql);
                                        if(mysqli_num_rows($result) > 0)
                                        {
                                                $row = mysqli_fetch_assoc($result);
                                                
                                                if($row['IsLogin'] == 1 && (strpos($row['Alert'], 'Friend|') === false))
                                                {
                                                        $sql = "UPDATE `Users` SET `Alert` = '".$row['Alert']."Friend|' WHERE `Username` = '".$x."'";
                                                        mysqli_query($con, $sql);
                                                        
                                                }
                                        }
                                }
                        //}
                        //else
                        //{
                                //echo "IP is different from previous login";
                        //
                }
                else
                {
                        echo "User already logged in";
                        
                }
	}
	else
        {
               echo "Failed";
        }
	
?>