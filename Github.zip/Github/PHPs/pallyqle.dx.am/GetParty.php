<?php

require './src/DBInfo.php';

        $Return = "";        
        $Username = $_REQUEST["Username"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Username."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                
                if($row['CurrentParty'] != "")
                {
                        $sql = "SELECT * FROM Users_Play 
                                WHERE `CurrentParty` = '".$row['CurrentParty']."' AND `Username` != '".$Username."'";
                        $result = mysqli_query($con, $sql);
                        if(mysqli_num_rows($result) > 0)
                        {
                                $Return = $row['CurrentParty']. "/" .$row['Leader'];
                                echo "{Content: \"".$Return."\"}";
                        }
                        else
                        {
                                $PartyArray = explode("|", $row['CurrentParty']);
                                foreach($PartyArray as $x)
                                {
                                        $sql = "SELECT * FROM Users_Play WHERE `Username` != '".$Username."' AND 
                                                `Username` = '".$x."' AND `Leader` != ''";     
                                        $result2 = mysqli_query($con, $sql);
                                        if(mysqli_num_rows($result2) > 0)
                                        {
                                                $row2 = mysqli_fetch_assoc($result2);
                                                                        
                                                if((strpos($row2['Alert'], 'Party:Decision:1:1:' .$row['Username']. ':' .$row['CurrentChar']. ':0|') === false))
                                                {
                                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert'] . "Party:Decision:1:1:" 
                                                                .$row['Username']. ":" .$row['CurrentChar']. ":0|' WHERE `Username` = '".$row2['Username']."'";
                                                        mysqli_query($con, $sql);
                                                }
                                                break;
                                        }
                                }
                                
                                $sql = "UPDATE `Users_Play` SET `CurrentParty` = '', `Leader` = '' WHERE `Username` = '".$Username."'";
                                mysqli_query($con, $sql);
                        }
                }
                
                echo "{Content: \"".$Return."\"}";
        }
        
?>