<?php

	require './src/DBInfo.php';
	
	$Return = ""; 
	$Email = $_REQUEST["Email"];
	$Verification = $_REQUEST["Verification"];    
        
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Save WHERE `Email` = '".$Email."' AND `Verification` = '".$Verification."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
		
			$row = mysqli_fetch_assoc($result);
			
			if($row['Verification'] == 1)
			{
				$Return = "Already Verified";
			}
			// Verify an account by setting it to 1
			else
			{
				$sql = "UPDATE `Users_Save` SET `Verification` = '1', `PrevIP` = ''
				WHERE `Email` = '".$Email."' AND `Verification` = '".$Verification."'";
				mysqli_query($con, $sql);
				
				$sql = "INSERT INTO `Users_Play` (`UserID`, `Username`, `IsLogin`, `MainIP`, `InstanceIP`, `PotentialGI`, `Alert`, 
				`CurrentChar`, `CurrentParty`, `Leader`, `XServerMessages`, `GIReady`) 
				VALUES ('".$row['UserID']."', '".$row['Username']."', '0', '', '', '', '', '', '', '', '', '')";  
				
				mysqli_query($con, $sql);
				$Return = "Verified";
			}
		}
		// Invalid Account
		else
		{
				$Return = "Error14";
		}
	}    
	echo $Return; 
?>