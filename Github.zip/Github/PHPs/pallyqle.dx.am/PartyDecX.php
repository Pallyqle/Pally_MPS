<?php

	require './src/DBInfo.php';
        
	$IsAccepted = $_REQUEST["IsAccepted"];
	$Inviter = $_REQUEST["Inviter"];
	$Members = $_REQUEST["Members"];
	$Invitee = $_REQUEST["Invitee"];
	$IsCancel = $_REQUEST["IsCancel"];
	$NewLeader = $_REQUEST["NewLeader"];
        
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		if($IsCancel == 0)
		{
			$InvitorArray = explode(",", $Members);
			foreach($InvitorArray as $x)
			{
				$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Invitee."'";
				$row = mysqli_fetch_assoc(mysqli_query($con, $sql));

				$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
				$result = mysqli_query($con, $sql);
				if(mysqli_num_rows($result) > 0)
				{
					$row2 = mysqli_fetch_assoc($result);
					
					if((strpos($row['Alert'], 'Party:Dec:0:0:'.$x.':'.':1|') === false))
					{						
						switch ($IsAccepted)
						{
							case 0:
								if((strpos($row2['Alert'], 'Party:Dec:1:1:'.$Invitee.':'.$IsCancel. '|') !== false))
								{
									$NewAlert = str_replace("Party:Dec:1:1:".$Invitee.":".$IsCancel."|", 
										"Party:Dec:0:1:".$Invitee.":".$IsCancel."|", $row2['Alert']);   
									$sql = "UPDATE `Users_Play` SET `Alert` = '".$NewAlert."' WHERE `Username` = '".$x."'";
									mysqli_query($con, $sql);
								}
								else if((strpos($row2['Alert'], 'Party:Dec:'.$IsAccepted.':1:'.$Invitee.':'.$IsCancel.'|') === false))
								{
									$sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."Party:Dec:".$IsAccepted.":1:".$Invitee.":".$IsCancel."|' 
										WHERE `Username` = '".$x."'";
									mysqli_query($con, $sql);
								}
								break;
							case 1:
								if((strpos($row2['Alert'], 'Party:Dec:0:1:'.$Invitee.':'.$IsCancel.'|') !== false))
								{
									$NewAlert = str_replace("Party:Dec:0:1:".$Invitee.":".$IsCancel."|",
										"Party:Dec:1:1:".$Invitee.":".$IsCancel."|", $row2['Alert']);   
									$sql = "UPDATE `Users_Play` SET `Alert` = '".$NewAlert."' WHERE `Username` = '".$x."'";
									mysqli_query($con, $sql);
								}
								else if((strpos($row2['Alert'], 'Party:Dec:'.$IsAccepted.':1:'.$Inviter.':'.$IsCancel.'|') === false))
								{
									$sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert'] . "Party:Dec:".$IsAccepted.":1:".$Invitee.":".$IsCancel."|' 
										WHERE `Username` = '".$x."'";
									mysqli_query($con, $sql);
								}
								break;   
							default:
								break;							
						}							
					}  
				}
			}
		}
		else
		{
				$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Invitee."'";
				$row = mysqli_fetch_assoc(mysqli_query($con, $sql));
				
				$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Inviter."'";
				$row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
				
				if((strpos($row['Alert'], 'Party:Dec:'.$IsAccepted.':0:'.$x.':'.$IsCancel.":".$NewLeader.'|') === false))
				{
						$sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Party:Dec:".$IsAccepted.":0:".$Inviter.":".$IsCancel.":".$NewLeader."|' 
							WHERE `Username` = '".$Invitee."'";
						mysqli_query($con, $sql);                                
				}   
				
				
				/*if($NewLeader == "")
				{
						if((strpos($row2['Alert'], 'Party:Decision:1:1:' .$row['Username']. ':' .$row['CurrentChar']. ':0|') !== false))
						{
								$NewAlert = str_replace("Party:Decision:1:1:" .$row['Username']. ":" .$row['CurrentChar']. ":0|"
												, "", $row2['Alert']);   
								$sql = "UPDATE `Users_Play` SET `Alert` = '".$NewAlert."' WHERE `Username` = '".$row2['Username']."'";
								mysqli_query($con, $sql);
						}     
						
						$InvitorArray = explode("|", $Members);
						foreach($InvitorArray as $x)
						{
								$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
								$result = mysqli_query($con, $sql);
								
								if(mysqli_num_rows($result) > 0)
								{
										$row3 = mysqli_fetch_assoc($result);
		
										if((strpos($row3['Alert'], 'Party:Decision:0:1:'.$row['Username'].':'.$row['CurrentChar'].':0|') === false))
										{
												$NewAlert = "Party:Decision:0:1:".$row['Username'].":".$row['CurrentChar'].":0|";   
												$sql = "UPDATE `Users_Play` SET `Alert` = '".$row3['Alert'].$NewAlert."' WHERE `Username` = '".$x."'";
												mysqli_query($con, $sql);
										}                        
		
								}
						}
				}
				else
				{
						$MyNewAlert = "";
						$NewAlert = "";    
						
						$AlertArray = explode("|", $row2['Alert']);
						foreach($AlertArray as $x)
						{

								if($x != "Party:Check" && (strpos($x, 'Party') !== false))
								{        
										$NewAlert .= $x."|";
								}
								else if($x != "")
								{
										$MyNewAlert .= $x."|";
								}
						}    
						
						if($NewAlert != "")
						{
								$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$NewLeader."'";     
								$row3 = mysqli_fetch_assoc(mysqli_query($con, $sql)); 
								
								$sql = "UPDATE `Users_Play` SET `Alert` = '".$row3['Alert'].$NewAlert."' WHERE `Username` = '".$NewLeader."'";
								mysqli_query($con, $sql);
						}
						
						$sql = "UPDATE `Users_Play` SET `Alert` = '".$MyNewAlert."' WHERE `Username` = '".$Inviter."'";
						mysqli_query($con, $sql);                        
				}   */            
				
		}

	}
	
	echo $Return;
?>