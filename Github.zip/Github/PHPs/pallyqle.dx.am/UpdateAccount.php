<?php

	require './src/DBInfo.php';
	
	$Return = "";
	
	$PrevDevice = $_REQUEST["PrevDevice"];
	$IsCharSelected = $_REQUEST["IsCharSelected"];
	//User Info
	$UserID = $_REQUEST["UserID"];
	$FavServers = $_REQUEST["FavServers"];
	$CharLimit = $_REQUEST["CharLimit"];
	$FriendList = $_REQUEST["FriendList"];
	$BlockedList = $_REQUEST["BlockedList"];
	$BankInv = $_REQUEST["BankInv"];
	//Char Info
	$Server = $_REQUEST["Server"];
	$Name = $_REQUEST["Name"];
	$Affiliation = $_REQUEST["Affiliation"];
	$XP = $_REQUEST["XP"];
	$Status = $_REQUEST["Status"];
	$Inv = $_REQUEST["Inv"];
	$Equips = $_REQUEST["Equips"];
	$Skills = $_REQUEST["Skills"];
	$Talents = $_REQUEST["Talents"];
	$Appearance = $_REQUEST["Appearance"];
	$Gameplay = $_REQUEST["Gameplay"];
	$Keybinds = $_REQUEST["Keybinds"];
	$KeyRemap = $_REQUEST["KeyRemap"];
	$Chat = $_REQUEST["Chat"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Save WHERE `UserID` = '".$UserID."'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);		
		
		// Check if logged in from another device
		if($row['PrevDevice'] == $PrevDevice)
		{				
			$sql = "UPDATE `Users_Save` SET `FavServers` = '".$FavServers."', `CharLimit` = '".$CharLimit."', `FriendList` = '".$FriendList."', 
					`BlockedList` = '".$BlockedList."', `BankInv` = '".$BankInv."' 
					WHERE `UserID` = '".$UserID."'";
			mysqli_query($con, $sql);				

			$sql = "UPDATE `Users_Char` SET `Server` = '".$Server."', `Name` = '".$Name."', `Affiliation` = '".$Affiliation."', `XP` = '".$XP."', 
			`Status` = '".$Status."', `Inv` = '".$Inv."', `Equips` = '".$Equips."', `Skills` = '".$Skills."', `Talents` = '".$Talents."', 
			`Appearance` = '".$Appearance."', `Gameplay` = '".$Gameplay."', `Keybinds` = '".$Keybinds."',  `KeyRemap` = '".$KeyRemap."',`Chat` = '".$Chat."' 
			WHERE `UserID` = '".$UserID."' && `Name` = '".$Name."'";
			mysqli_query($con, $sql);
		
			// $sql = "SELECT * FROM Users_Save WHERE `UserID` = '".$UserID."'";
			// $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
						   
			// $FriendList = explode("|", $FriendList);
			// foreach($FriendList as $x)
			// {
				// $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$x."'";
				// $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
				
				// $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
				// $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
				
				// if($row2['IsLogin'] == 1 && (strpos($row2['Alert'], 'Friend|') === false) && (strpos($row['FriendList'], $Username) !== false))
				// {
					// $sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."Friend|' 
							// WHERE `Username` = '".$x."'";
					// mysqli_query($con, $sql);
						
				// }
			// } 
			
			if($IsCharSelected == 1)
			{     
				$sql = "UPDATE `Users_Play` SET `CurrentChar` = '".$Name."' WHERE `UserID` = '".$UserID."'";		
				mysqli_query($con, $sql);
			}
			$Return = "Success5";				
		}
		//Disconnect prompt
		else
		{
			$Return = "Prompt2"; 
		}

	}
	echo $Return; 
?>