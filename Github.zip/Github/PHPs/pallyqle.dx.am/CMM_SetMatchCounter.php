<?php
        
	require './src/DBInfo.php';
	
	$Return = "";
	$Members = $_REQUEST["Members"];
	$WaitState = $_REQUEST["WaitState"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$MemberList = explode(",", $Members);
		foreach($MemberList as $x)
		{		
			$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
			$result = mysqli_query($con, $sql);
			if(mysqli_num_rows($result) > 0)
			{		
				$row = mysqli_fetch_assoc($result);

				if($row['IsLogin'] == 1 && (strpos($row['Alert'], 'Counter:'.$WaitState.'|') === false))
				{							
					$sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Counter:".$WaitState."|' 
						WHERE `Username` = '".$x."'";
					mysqli_query($con, $sql);
				}
			}	
		}
		
		$Return = "Counter Started";
	}
	echo $Return; 
?>