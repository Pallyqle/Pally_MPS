<?php

require './src/DBInfo.php';

        $Return = "";
        $Username = $_REQUEST["Username"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
                if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Char WHERE `Name` = '".$Username."'";
                $result = mysqli_query($con, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                        $row = mysqli_fetch_assoc($result);
                        
                        $Return = $row['Username']; 
                        echo "{Content: \"".$Return."\"}";                                                   
                }
                else
                {
                        $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$Username."'";
                        $result = mysqli_query($con, $sql);                
                        if(mysqli_num_rows($result) > 0)
                        {
                                $row = mysqli_fetch_assoc($result);
                                
                                $Return = $row['Username']; 
                                echo "{Content: \"".$Return."\"}"; 
                        }
                        else
                        {
                                $Return = "User Or Character Does Not Exist";
                                echo "{Content: \"".$Return."\"}"; 
                        }
                }
        }
?>