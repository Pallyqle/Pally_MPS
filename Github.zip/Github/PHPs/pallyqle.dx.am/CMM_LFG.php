<?php
        
	require './src/DBInfo.php';
	
	$Return = "";
	$Requester = $_REQUEST["Requester"];
	$Members = $_REQUEST["Members"];
	$LFGAction = $_REQUEST["LFGAction"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$MemberList = explode(",", $Members);
		foreach($MemberList as $x)
		{		
			$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
			$result = mysqli_query($con, $sql);
			if(mysqli_num_rows($result) > 0)
			{		
				$row = mysqli_fetch_assoc($result);

				if($row['IsLogin'] == 1 && (strpos($row['Alert'], 'LFG:'.$LFGAction.'|') === false) && $x != $Requester)
				{							
					$sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."LFG:".$LFGAction."|' 
						WHERE `Username` = '".$x."'";
					mysqli_query($con, $sql);
				}
			}	
		}
		
		Switch($LFGAction)
		{
			case "Started":
				$Return = "LFG Started";
				break;
			case "Canceled":
				$Return = "LFG Canceled";
				break;
			default:
				break;
		}
	}
	echo $Return; 
?>