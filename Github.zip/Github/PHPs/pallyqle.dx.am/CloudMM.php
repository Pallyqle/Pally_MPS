<?php
        
	require './src/DBInfo.php';
	
	$Return = "";
	$Requester = $_REQUEST["Requester"];
	$Members = $_REQUEST["Members"];
	$HostRequest = $_REQUEST["HostRequest"];
	$GameType = $_REQUEST["GameType"];
	$TeamCount = $_REQUEST["TeamCount"];
	$MNP = $_REQUEST["MNP"];
	$IsCanceled = $_REQUEST["IsCanceled"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM LFG  WHERE `Members` = '".$Members."' && `IsCanceled` = '".$IsCanceled."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			
		}
		else
		{
			$sql = "INSERT INTO `LFG` (`ID`, `Requester`, `Members`, `HostRequest`, `GameType`, `TeamCount`, `MNP`, `IsCanceled`) 
				VALUES (Null, '$Requester', '$Members', '$HostRequest', '$GameType', '$TeamCount', '$MNP', '$IsCanceled')";
			mysqli_query($con, $sql);
			if($IsCanceled)
			{
				$Return = "Success11"; 			
			}
			else
			{
				$Return = "Success9"; 	
			}			
		}
	}
	echo $Return; 
?>