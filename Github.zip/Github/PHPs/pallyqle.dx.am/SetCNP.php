<?php

	require './src/DBInfo.php';
	
	$Return = "";
	$IP = $_REQUEST["IP"];
	$Port = $_REQUEST["Port"];
	$NumPlayer = $_REQUEST["NumPlayer"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
			$Return = "Error0";
			exit();
			$con->close();
	} 
	else
	{
		$sql = "SELECT CNP FROM Servers WHERE `IP` = '".$IP."' && `Port` = '".$Port."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			$row = mysqli_fetch_assoc($result);
			
			$sql = "UPDATE `Servers` SET `CNP` = '".$NumPlayer."' WHERE `IP` = '".$IP."' && `Port` = '".$Port."'";
			mysqli_query($con, $sql);
			
			$Return = "Success14";
		}		
		else
		{
			$Return = "Error12";
		}
	}
	echo $Return; 
?>