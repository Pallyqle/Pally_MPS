<?php

require './src/DBInfo.php';

	$Username = $_POST["Username"];
	$Password = $_POST["Password"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	$sql = "SELECT * FROM Users_Save WHERE `Username` = '".$Username."'";
	$result = mysqli_query($con, $sql);
	if(mysqli_num_rows($result) > 0)
	{
                echo "Failed";
	}
	else
	{
		$sql = "INSERT INTO `Users_Save` (`Username`, `Password`, `Verification`, `FriendList`, `BlockedList`, `BankInv`, `ChatTab`) 
                        VALUES ('".$Username."', '".$Password."', '', '', '', '', 'Say|1|1|0|0|~Whisper|1|0|0|1|~Party|1|0|1|0|~')";
		mysqli_query($con, $sql);
		
                $sql = "INSERT INTO `Users_Play` (`Username`, `UserIP`, `IsLogin`, `MainIP`, `InstanceIP`, `PotentialGI`, `Alert`, 
                        `CurrentChar`, `CurrentParty`, `XServerMessages`, `GIReady`)
                        VALUES ('".$Username."', '', '0', '', '', '', '', '', '', '', '')";
                        
		mysqli_query($con, $sql);
                
                $sql = "INSERT INTO `Users_Option` (`Username`) VALUES ('".$Username."')";
                        
		mysqli_query($con, $sql);
                
                echo "Success"; 
	}

?>