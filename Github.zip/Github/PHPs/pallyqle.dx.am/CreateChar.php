<?php

	require './src/DBInfo.php';

	$Return = "";

	$PrevDevice = $_REQUEST["PrevDevice"];
	$UserID = $_REQUEST["UserID"];
	$Name = $_REQUEST["Name"];
	$Affiliation = $_REQUEST["Affiliation"];
	$XP = $_REQUEST["XP"];
	$Status = $_REQUEST["Status"];
	$Inv = $_REQUEST["Inv"];
	$Equips = $_REQUEST["Equips"];
	$Skills = $_REQUEST["Skills"];
	$Talents = $_REQUEST["Talents"];
	$Appearance = $_REQUEST["Appearance"];
	$Gameplay = $_REQUEST["Gameplay"];
	$Keybinds = $_REQUEST["Keybinds"];
	$KeyRemap = $_REQUEST["KeyRemap"];
	$ChatTab = $_REQUEST["Chat"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Save WHERE `UserID` = '".$UserID."'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);		
		
		// Check if logged in from another device
		if($row['PrevDevice'] == $PrevDevice)
		{			
			$sql = "SELECT * FROM Users_Char WHERE `Name` = '".$Name."'";
			$result = mysqli_query($con, $sql);
			
			// Check if the character name is already taken
			// Insert a new character profile into the database
			if(mysqli_num_rows($result) == 0)
			{
					$sql = "INSERT INTO Users_Char (UserID, Server, Name, Affiliation, XP, Status, Inv, Equips, Skills, Talents, 
								Appearance, Gameplay, Keybinds, KeyRemap, Chat) 
							VALUE('$UserID', '', '$Name', '$Affiliation', '$XP', '$Status', '$Inv', '$Equips', '$Skills', '$Talents', 
								'$Appearance', '$Gameplay', '$Keybinds', '$KeyRemap', '$Chat')";
					mysqli_query($con, $sql);
					
					$Return = "Success4";
			}
			else
			{
				$Return = "Error6";
			}
		}
		//Disconnect prompt
		else
		{
			$Return = "Prompt2"; 
		}
	}
	echo $Return;		
?>