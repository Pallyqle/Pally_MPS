<?php

	require './src/DBInfo.php';

	$Return = "";
	$Username = $_REQUEST["Username"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
			$Return = "Error0";
			echo "{Content: \"".$Return."\"}"; 
			exit();
			$con->close();
	} 
	else
	{
			$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Username."'";
			$row = mysqli_fetch_assoc(mysqli_query($con, $sql));
			
			$Return = $row['GIReady'];
			
	}
	
	echo $Return;
        
?>