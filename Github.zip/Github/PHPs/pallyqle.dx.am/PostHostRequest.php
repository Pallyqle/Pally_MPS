<?php
        
	require './src/DBInfo.php';
	
	$Return = "";
	$CurServerCount = "";
	$Hosts = $_REQUEST["Hosts"];
	$ServerType = $_REQUEST["ServerType"];
	$Name = $_REQUEST["Name"];
	$Password = $_REQUEST["Password"];
	$Region = $_REQUEST["Region"];
	$MNP = $_REQUEST["MNP"];
	$PG = $_REQUEST["PG"];
	$IG = $_REQUEST["IG"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Servers";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				if($row['ServerType'] == $ServerType)
				{
					 if($Name == "Official")
					 {					 
						$CurNumber = str_replace($Name," ",$row['Name']);
						if($CurNumber - $NextNumber <= 1)
						{
							$NextNumber = str_replace($Name," ",$row['Name']);
						}							
					}
					if($Name == "Instance")
					{
						$CurNumber = str_replace($Name," ",$row['Name']);
						if($CurNumber - $NextNumber <= 1)
						{
							$NextNumber = str_replace($Name," ",$row['Name']);
						}
					}
				}
			}
		}	
		
		$Name .= " ".($NextNumber + 1);
		
		$sql = "INSERT INTO `DS_HostInfo` (`Hosts`, `ServerType`, `Name`, `Password`, `Region`, `MNP`, `PG`, `IG`) 
				VALUES ('$Hosts', '$ServerType', '$Name', '$Password', '$Region', '$MNP', '$PG', '$IG')";
		mysqli_query($con, $sql);
		
		$sql = "INSERT INTO `DS_CreationRequest` (`RequestIndex`, `Region`, `ServerType`) VALUES (NULL, '$Region', '$ServerType')";
		mysqli_query($con, $sql);
		
		$Return = "Success6";
	}
	echo $Return; 
?>