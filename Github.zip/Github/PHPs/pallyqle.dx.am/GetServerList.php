<?php
        
	require './src/DBInfo.php';
		
	$Return = "";
	$ServerType = $_REQUEST["ServerType"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Servers WHERE `ServerType` = '".$ServerType."' AND `Password` != 'Thienhoang1'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				$Return .= $row['ServerType']."/".$row['IP']."/".$row['Port']."/".$row['Name']."/".$row['Password']."/".
					$row['Region']."/".$row['IsInGame']."/".$row['CNP']."/".$row['MNP']."/".$row['PG']."/".$row['IG'].";";
			}
		}      
		else
		{
			$Return = "Error12";
		}
	}
	echo $Return;	
?>