<?php
	
	require './src/DBInfo.php';
	
	$Return = "";
        
	$ServerType = $_REQUEST["ServerType"];
	$IP = $_REQUEST["IP"];
	$Port = $_REQUEST["Port"];  

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Servers WHERE `IP` = '".$IP."' AND `Port` = '".$Port."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			$row = mysqli_fetch_assoc($result);
			$Return = "Error10";
		}
		else
		{

			$sql = "INSERT INTO `Servers` (`ID`, `ServerType`, `IP`, `Port`, `Name`, `Password`, `Region`,
					`IsInGame`, `CNP`, `MNP`, `PG`, `IG`) 
					VALUES (NULL, '$ServerType', '$IP', '$Port', '', 'Thienhoang1', '', '0', '0', '0', '', '')";
			mysqli_query($con, $sql);				
				
			$Return = "Success13";							  
		}        
	}
	echo $Return;
?>