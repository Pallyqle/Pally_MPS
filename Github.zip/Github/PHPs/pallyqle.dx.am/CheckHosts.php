<?php
	
	require './src/DBInfo.php';
	
	$Return = "";
	$ServerType = $_REQUEST["ServerType"];
	$IP = $_REQUEST["IP"];
	$Port = $_REQUEST["Port"];
	$GIIPPort = "";

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM DS_HostInfo";
		$result = mysqli_query($con, $sql);
		  
		if(mysqli_num_rows($result) > 0)
		{
			$IsFirst = true;
			while ($row = $result->fetch_assoc()) 
			{
				if($IsFirst == true && $row['ServerType'] == $ServerType)
				{
					$sql = "UPDATE `Servers` SET `Name` = '".$row['Name']."', `Region` = '".$row['Region']."', 
					`MNP` = '".$row['MNP']."', `PG` = '".$row['PG']."', `IG` = '".$row['IG']."' 
					WHERE `IP` = '".$IP."' && `Port` = '".$Port."'";                                      

					mysqli_query($con, $sql);
					
					$GIIPPort = $IP .":". $Port; 
						
					if($row['Password'] == "")
					{
						$Return = "Public/";
					}
					else 
					{
						$Return = "Private/";
					}

					
					$Return .= $row['Name']."/".$row['Password']."/".$row['Region']."/".$row['MNP']."/"
							.$row['PG']."/".$row['IG'];							
				  
					if($ServerType == "GI")
					{
						$Hosts = explode("|", $row['Hosts']);                     
						foreach ($Hosts as $x) 
						{                                                                  
							$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
							$result = mysqli_query($con, $sql);
							  
							if(mysqli_num_rows($result) > 0)
							{       
							   $row2 = mysqli_fetch_assoc($result);
							   
							   $sql = "UPDATE `Users_Play` SET `GIReady` = '".$GIIPPort."' WHERE `Username` = '".$x."'";
							   mysqli_query($con, $sql);
								   
							   if(strpos($row2['Alert'], 'GIReady') === false)
							   {                                                               
									   $sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."GIReady|' WHERE `Username` = '".$x."'";
									   mysqli_query($con, $sql);
							   }                                                                           
							}                      
						}
					}
										   
					$sql = "DELETE FROM DS_HostInfo WHERE `Name` = '".$row['Name']."'";
					mysqli_query($con, $sql);
					
					$IsFirst = false;
					break;
				}
			}
			if($IsFirst == true)
			{
				$Return = "Error7";
			}
		}
		else
		{
			$Return = "Error7";

		}
	}
	echo $Return; 
?>