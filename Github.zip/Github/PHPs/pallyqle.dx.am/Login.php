<?php

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require './src/Exception.php';
	require './src/PHPMailer.php';
	require './src/SMTP.php';
	require './src/DBInfo.php';
	
	$Return = "";
        
	$Username = $_REQUEST["Username"];
	$Password = $_REQUEST["Password"];
	$PrevDevice = $_REQUEST["PrevDevice"];
	$IsPlatform = $_REQUEST["IsPlatform"];
	$IP = $_SERVER['REMOTE_ADDR'];
	$Verification = bin2hex(random_bytes(2));  

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{                
		$sql = "SELECT * FROM Users_Save  WHERE `Username` = '".$Username."' OR `Email` = '".$Username."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{		
			$row = mysqli_fetch_assoc($result);
	
			$sql = "SELECT * FROM Users_Play WHERE `UserID` = '".$row['UserID']."'";
			
			$row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
			
			// Check password or if logged in from other platforms like Steam, PSN, XBox
			if($row['Password'] == $Password || $IsPlatform == 1)
			{
				// Check account verification
				if($row['Verification'] == "1")
				{
					// Check if already logged in
					if($row2['IsLogin'] == 0)
					{            
						// Check if IP is different from previous login
						// Ignore if logging in from other platforms
						if($row['PrevIP'] == $IP || $row['PrevIP'] == "" || $IsPlatform == 1)
						{
							$sql = "UPDATE `Users_Save` SET `PrevIP` = '".$IP."', `PrevLogin` = '', `PrevDevice` = '".$PrevDevice."'
								WHERE `UserID` = '".$row['UserID']."'";
							mysqli_query($con, $sql); 
							
							$sql = "UPDATE `Users_Play` SET `IsLogin` = '1', `CurrentChar` = ''
								WHERE `UserID` = '".$row['UserID']."'";
							mysqli_query($con, $sql); 
							
							if((strpos($row2['Alert'], 'Login:'.$PrevDevice.'|') === false))
							{
								$sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."Login:".$PrevDevice."|'
									WHERE `UserID` = '".$row['UserID']."'";
								mysqli_query($con, $sql);
							}
							// Return player unique ID and username
							$Return = $row['UserID']."/".$row['Username'];
							
							// Notify the user's friend that they'd logged in
							$FriendList = explode("|", $row['FriendList']);
							foreach($FriendList as $x)
							{
								// $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$x."'";
								// $row3 = mysqli_fetch_assoc(mysqli_query($con, $sql));
								
								// $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
								// $row4 = mysqli_fetch_assoc(mysqli_query($con, $sql));
								
								// if($row4['IsLogin'] == 1 && (strpos($row4['Alert'], 'Friend|') === false) 
												// && (strpos($row3['FriendList'], $Username) !== false))
								// {
									// $sql = "UPDATE `Users_Play` SET `Alert` = '".$row4['Alert']."Friend|' 
													// WHERE `Username` = '".$x."'";
									// mysqli_query($con, $sql);
												
								// }
							}
							// Notify party members that user have connected
							if($row2['CurrentParty'] != "")
							{
								// $sql = "SELECT * FROM Users_Play 
										// WHERE `CurrentParty` = '".$row2['CurrentParty']."' AND `Username` != '".$Username."'";
								// $result = mysqli_query($con, $sql);
								// if(mysqli_num_rows($result) > 0)
								// {
									// $NormalParty = str_replace("*", "", $row2['CurrentParty']);
									// $PartyArray = explode("|", $NormalParty);
									// foreach($PartyArray as $x)
									// {
																																																						
										// $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
										// $row5 = mysqli_fetch_assoc(mysqli_query($con, $sql));

										// if($row5['IsLogin'] == 1 && $row5['Username'] != $Username && (strpos($row5['Alert'], 'Party:Check|') === false))
										// {
											// $sql = "UPDATE `Users_Play` SET `Alert` = '".$row5['Alert']."Party:Check|' 
															// WHERE `Username` = '".$row5['Username']."'";
											// mysqli_query($con, $sql);
										// }
									// }
								// }
								// else
								// {
									// $sql = "UPDATE `Users_Play` SET `CurrentParty` = '' WHERE `Username` = '".$Username."'";
									// mysqli_query($con, $sql);
								// }
							}
						}
						// Different IP from previous log in
						// Set and send new verification
						else
						{                          
							$sql = "UPDATE `Users_Save` SET `Verification` = '".$Verification."'
									WHERE `UserID` = '".$row['UserID']."'";	
							mysqli_query($con, $sql); 	
							
							$Return = "Error4";
							$Email = $row['Email'];
							
							$mail = new PHPMailer(true);

							$mail->SMTPDebug = 0;

							$mail->Host = "smtp.mboxhosting.com";
							$mail->SMTPAuth = true;
							$mail->Username = $DBEmail;
							$mail->Password = $DBPassword;
							$mail->SMTPSecure = "tls";
							$mail->Port = 465;
							$mail->setFrom("noreply@pallyqle.dx.am", "Pallyqle");
							$mail->addAddress($Email);
							$mail->isHTML(true);    
							$mail->Subject = "Email Verification Test";
							$mail->Body = '<h1> Different IP from previous login. </h1>
											<p> Click the link to re-verify your account: 
											<br> http://www.pallyqle.dx.am/Verification.php?Email='.$Email.'&Verification='.$Verification.'
											</p>
							';      

							$mail->send();	
						}
					}
					// User already logged in
					// Set Islogin back to 0 and notify other devices to log out.
					else
					{
						$sql = "UPDATE `Users_Save` SET `PrevDevice` = '".$PrevDevice."'
								WHERE `UserID` = '".$row['UserID']."'";
						mysqli_query($con, $sql); 
							
						$sql = "UPDATE `Users_Play` SET `IsLogin` = '0' 
								WHERE `UserID` = '".$row['UserID']."'";
						mysqli_query($con, $sql); 
						
						if((strpos($row2['Alert'], 'Login:'.$PrevDevice.'|') === false))
						{
							$sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."Login:".$PrevDevice."|' 
								WHERE `UserID` = '".$row['UserID']."'";
							mysqli_query($con, $sql);
						}
						$Return = "Error3";                                
					}
				}
				// Account not verified
				else
				{
					if(strlen($row['Verification']) < 16)
					{
						$Return = "Prompt4";
					}
					else
					{
						$Return = "Prompt0";
					}
				}                                
			}
			// Incorrect password
			else
			{
				$Return = "Error2";
			}						
		}
		// Create an user if logging in from another platform for the first time
		// Platform accounts are automatically verified
		// Return newly created user unique ID and username
		else if($IsPlatform == 1)
		{
			$sql = "INSERT INTO `Users_Save` (`UserID`, `Username`, `Email`, `Verification`, `Password`, `PrevIP`, `PrevLogin`, `FavServers`, `CharLimit`, `FriendList`, `BlockedList`, `BankInv`) 
			VALUES (NULL, '".$Username."', '', '1', '', '', '', '', '4', '', '', '')";
			
			mysqli_query($con, $sql);    	

			$sql = "SELECT * FROM Users_Save  WHERE `Username` = '".$Username."' OR `Email` = '".$Username."'";
			$result = mysqli_query($con, $sql);
			if(mysqli_num_rows($result) > 0)
			{
				$row = mysqli_fetch_assoc($result);
				
				$sql = "INSERT INTO `Users_Play` (`UserID`, `Username`, `IsLogin`, `MainIP`, `InstanceIP`, `PotentialGI`, `Alert`, `CurrentChar`, `CurrentParty`, `Leader`, `XServerMessages`, `GIReady`) 
				VALUES ('".$row['UserID']."', '".$row['Username']."', '0', '', '', '', '', '', '', '', '', '')";  
					
				mysqli_query($con, $sql);
			
				$Return = $row['UserID']."/".$row['Username'];
			}
			// Fail to create an account
			else
			{
				$Return = "Error15"; 
			}
		}
		// Invalid account
		else
		{
			$Return = "Error1";   
		}
	}
	echo $Return; 
?>