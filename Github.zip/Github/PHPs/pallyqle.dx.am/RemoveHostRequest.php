<?php

require './src/DBInfo.php';

        $Return = "";        
	$Hosts = $_REQUEST["Hosts"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "DELETE FROM DS_HostInfo WHERE `Hosts` = '".$Hosts."'";
                mysqli_query($con, $sql);  
                
                $Return = "Request Removed";
                echo "{Content: \"".$Return."\"}";
        }
        
?>