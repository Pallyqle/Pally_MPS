<?php

require './src/DBInfo.php';

        $Return = "";
        //$FriendList = "Pallyqle";
        
	$FriendList = $_REQUEST["FriendList"];
        $FriendNormal = str_replace("*", "", $FriendList);
        $Friends = explode("|", $FriendNormal);
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                if($FriendNormal != "")
                {
                        foreach($Friends as $x)
                        {
                                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                                $result = mysqli_query($con, $sql);
                                if(mysqli_num_rows($result) > 0)
                                {
                                        $row = mysqli_fetch_assoc($result);
                                        
                                        $Return .= $row['Username']."/".$row['IsLogin']."/".$row['MainIP']."/".$row['InstanceIP']
                                                        ."/".$row['CurrentChar']."/".$row['CurrentParty']."/".$row['Leader'];
                                                        
                                        if($row['CurrentChar'] != "")
                                        {
                                                $sql = "SELECT * FROM Users_Char WHERE `Name` = '".$row['CurrentChar']."'";                                        
                                                $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                                        
                                                $Return .= "/".$row2['Exp']."/".$row2['Equips'];
                                        }
                                        else
                                        {
                                                $Return .= "/".""."/"."";
                                        }
                                        if($row['MainIP'] != "" && $row['MainIP'] != ":")
                                        {
                                                $FullIP = explode(":", $row['MainIP']); 
                                                
                                                $sql = "SELECT * FROM Servers WHERE `IP` = '".$FullIP[0]."' 
                                                        AND `PortNumber` = '".$FullIP[1]."'";
                                                $result = mysqli_query($con, $sql);
                                                if(mysqli_num_rows($result) > 0)
                                                {
                                                        $row3 = mysqli_fetch_assoc($result);
                                                        
                                                        $Return .= "/".$row3['ServerType'].":".$row3['Name'].$row3['Password'].":"
                                                                .$row3['IsInGame'].":".$row3['GameType'].":".$row3['TeamCount'].":"
                                                                .$row3['MapName'].":".$row3['CNP'].":".$row3['MNP'].":".$row3['WinCond'].":"
                                                                .$row3['Extras'];
                                                }
                                        }
                                        else
                                        {
                                                $Return .= "/"."";
                                        }
                                        if($row['InstanceIP'] != "")
                                        {
                                                $FullIP = explode(":", $row['InstanceIP']); 
                                                
                                                $sql = "SELECT * FROM Servers WHERE `IP` = '".$FullIP[0]."' 
                                                        AND `PortNumber` = '".$FullIP[1]."'";
                                                $result = mysqli_query($con, $sql);
                                                if(mysqli_num_rows($result) > 0)
                                                {
                                                        $row3 = mysqli_fetch_assoc($result);
                                                        
                                                        $Return .= "/".$row3['ServerType'].":".$row3['Name'].$row3['Password'].":"
                                                                .$row3['IsInGame'].":".$row3['GameType'].":".$row3['TeamCount'].":"
                                                                .$row3['MapName'].":".$row3['CNP'].":".$row3['MNP'].":".$row3['WinCond'].":"
                                                                .$row3['Extras'];
                                                }
                                        }
                                        else 
                                        {
                                                $Return .= "/".""."/"."".";";
                                        }              
                                } 
                        }
                        if($Return != "")
                        {
                                echo "{Content: \"".$Return."\"}"; 
                        }
                        
                }
        }
        
?>