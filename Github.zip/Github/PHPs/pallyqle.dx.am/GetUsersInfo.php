<?php

require './src/DBInfo.php';

	$Return = "";
	//$UserID = "";

	$UserID = $_REQUEST["UserID"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		//Login was correct so no need to if check
		$sql = "SELECT * FROM Users_Save WHERE `UserID` = '".$UserID."'";
		$row = mysqli_fetch_assoc(mysqli_query($con, $sql));
		
		$Return = $row['FavServers']."/".$row['CharLimit']."/".$row['FriendList']."/".$row['BlockedList']."/".$row['BankInv'];					
	}
	echo $Return; 
?>