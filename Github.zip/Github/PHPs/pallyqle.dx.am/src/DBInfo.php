<?php
        
    $FTP = "pdb43.awardspace.net";
	$DBUsername = "2040551_rts";
	$DBPassword = "Thienhoang1";
	$DBName = "2040551_rts";
	$DBEmail = "pallyqle@pallyqle.dx.am";
?>