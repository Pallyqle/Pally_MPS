<?php

require './src/DBInfo.php';

        $Return = "";
        $Username = "Pallyqle";
	$CurrentChar = "pallyqlee";
        
	//$Username = $_REQUEST["Username"];
	//$CurrentChar = $_REQUEST["CurrentChar"];
        
        $con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users WHERE `Username` = '".$Username."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                   
                $sql = "UPDATE `Users_Play` SET `CurrentChar` = '".$CurrentChar."' WHERE `Username` = '".$Username."'";
                mysqli_query($con, $sql);  
                
                $FriendList = explode("|", $row['FriendList']);
                foreach($FriendList as $x)
                {
                        $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$x."'";
                        $row3 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                        
                        $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
                        $row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
                        
                        if($row3['IsLogin'] == 1 && (strpos($row3['Alert'], 'Friend|') === false) 
                                && (strpos($row2['FriendList'], $Username) !== false))
                        {
                                $sql = "UPDATE `Users_Play` SET `Alert` = '".$row3['Alert']."Friend|' 
                                        WHERE `Username` = '".$x."'";
                                mysqli_query($con, $sql);
                                
                        }
                }
	}
?>