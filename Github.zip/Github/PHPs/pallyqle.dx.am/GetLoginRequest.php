<?php
	
	require './src/DBInfo.php';
	
        $Return = "";
        $IP = $_REQUEST["IP"];
        
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Error0";
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM DS_LoginRequest WHERE `IP` = '".$IP."'";
                $result = mysqli_query($con, $sql);
                
                if(mysqli_num_rows($result) > 0)
                {
                        $row = mysqli_fetch_assoc($result);
                                                
                        $Return = $row['Username'];
                        
                        $sql = "DELETE FROM DS_LoginRequest WHERE `RequestIndex` = '".$row['RequestIndex']."'";
                        mysqli_query($con, $sql);		                                        
                }
                else
                {
                        $Return = "Error13";              
                }
        }
	echo $Return;
	
?>