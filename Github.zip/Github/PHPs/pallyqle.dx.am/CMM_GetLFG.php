<?php
        
	require './src/DBInfo.php';
	
	$Return = "";

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM LFG";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{			
				$Return .= $row['Requester']."/".$row['Members']."/".$row['HostRequest']."/".$row['GameType']."/".$row['TeamCount']."/".$row['MNP'].
					"/".$row['IsCanceled'].";";
			}
			mysqli_query($con, 'TRUNCATE TABLE LFG');
		}
		else
		{			
			$Return = "Error1";
		}
	}
	echo $Return; 
?>