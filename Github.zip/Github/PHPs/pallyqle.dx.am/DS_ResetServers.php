<?php

	require './src/DBInfo.php';
	
	$Return = "";
	$IsStarted = $_POST["IsStarted"];
        
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0"; 
		exit();
		$con->close();
	}
	else
	{
		mysqli_query($con, 'TRUNCATE TABLE DS_CreationRequest');
		mysqli_query($con, 'TRUNCATE TABLE DS_HostInfo');
		mysqli_query($con, 'TRUNCATE TABLE DS_LoginRequest');
		mysqli_query($con, 'TRUNCATE TABLE Servers');
		mysqli_query($con, 'TRUNCATE TABLE LFG');
		
		$Return = "Cleared";
	}
	echo $Return;
?>