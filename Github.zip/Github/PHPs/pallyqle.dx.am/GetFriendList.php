<?php

require './src/DBInfo.php';

        $Return = "";
        $Username = "Pallyqle";
        
	//$Username = $_REQUEST["Username"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Save WHERE `Username` = '".$Username."'";
                $row = mysqli_fetch_assoc(mysqli_query($con, $sql));
                
                $Return = $row['FriendList'];
                echo "{Content: \"".$Return."\"}";
        }
        
?>