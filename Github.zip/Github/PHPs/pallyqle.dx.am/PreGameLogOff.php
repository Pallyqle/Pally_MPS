<?php

require './src/DBInfo.php';

	$Username = $_POST["Username"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	
	$sql = "UPDATE `Users` SET `IsLogin` = '0' WHERE `Username` = '".$Username."'";
	mysqli_query($con, $sql);
        
        $sql = "SELECT FriendList FROM Users WHERE `Username` = '".$Username."'";
        $result = mysqli_query($con, $sql);
        
        if(mysqli_num_rows($result) > 0)
        {
                $row = mysqli_fetch_assoc($result);
                
                $FriendList = explode("|", $row['FriendList']);
                foreach($FriendList as $x)
                {
                        $sql = "SELECT Alert, IsLogin FROM Users WHERE `Username` = '".$x."'";
                        $result = mysqli_query($con, $sql);
                        echo $x;
                        if(mysqli_num_rows($result) > 0)
                        {
                                $row = mysqli_fetch_assoc($result);
                                if($row['IsLogin'] == 1 && (strpos($row['Alert'], 'Friend') === false))
                                {
                                        $sql = "UPDATE `Users` SET `Alert` = '".$row['Alert']."Friend|' WHERE `Username` = '".$x."'";
                                        mysqli_query($con, $sql);
                                        
                                }
                        }
                }
        }
        
        echo $Username
	
?>