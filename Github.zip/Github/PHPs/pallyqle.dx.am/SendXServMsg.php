<?php

require './src/DBInfo.php';
        
        $Return = "";
	$CurrentName = $_REQUEST["CurrentName"];
	$Message = $_REQUEST["Message"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Username."'";
                $result = mysqli_query($con, $sql);
                
                if(mysqli_num_rows($result) > 0)
                {
                        $row = mysqli_fetch_assoc($result);
                        
                        if($row['IsLogin'] == 1)
                        {
                           $sql = "UPDATE `Users_Play` SET `XServerMessages` = '".$row['XServerMessages'].$Message."' WHERE `Username` = '".$Username."'";
                           mysqli_query($con, $sql);
                  
                                if($row['CurrentChar'] != '')
                                {
                                        $Return = $row['CurrentChar'];
                                        echo "{Content: \"".$Return."\"}"; 
                                }
                                else
                                {
                                        $Return = $row['Username']
                                        echo "{Content: \"".$Return."\"}";
                                }  	   
                                if(strpos($row['Alert'], 'Message') === false)
                                {   
                                        $sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Message|' WHERE `Username` = '".$Username."'";
                                        mysqli_query($con, $sql);	   
                                }
                        }
                        else
                        {
                                Return = "User Is Offline";
                                echo "{Content: \"".$Return."\"}"; 
                        }
                }               
                else
                {
                        $Return = "User Not Found";
                        echo "{Content: \"".$Return."\"}";                 
                }
        }    

?>