<?php
        
	require './src/DBInfo.php';
	
	$Return = "";
	$Members = $_REQUEST["Members"];
	$Leavers = $_REQUEST["Leavers"];
	$IsJoining = $_REQUEST["IsJoining"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$TrimMember = "";
		$MemberList = explode(",", $Members);
		foreach($MemberList as $x)
		{		
			$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
			$result = mysqli_query($con, $sql);
			if(mysqli_num_rows($result) > 0)
			{		
				$row = mysqli_fetch_assoc($result);
				
				if($IsJoining == 1)
				{
					$TrimMember = str_replace($x.",","", $Members);

				}
				else
				{
					$TrimMember = str_replace($x.",","", $Leavers);
				}
				if($TrimMember != "")
				{
					if($row['IsLogin'] == 1 && (strpos($row['Alert'], 'Group:'.$TrimMember.':'.$IsJoining.'|') === false))
					{	
						$sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Group:".$TrimMember.":".$IsJoining."|' 
							WHERE `Username` = '".$x."'";
						mysqli_query($con, $sql);
					}
				}
			}			
		}
		
		$Return = "Info Shared";
	}
	echo $Return; 
?>