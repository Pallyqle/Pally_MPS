<?php

	require './src/DBInfo.php';

	$Return = "";
	$Leaver = $_REQUEST["Leaver"];
	$NewLeader = $_REQUEST["NewLeader"];
	$Members = $_REQUEST["Members"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Leaver."'";
		$row = mysqli_fetch_assoc(mysqli_query($con, $sql));

		$MembersArray = explode(",", $Members);
		foreach($MembersArray as $x)
		{      
			$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
			$row2 = mysqli_fetch_assoc(mysqli_query($con, $sql));
			
			if((strpos($row2['Alert'], 'Party:Left:'.":".$Leaver.":".$NewLeader.'|') === false))
			{
				$sql = "UPDATE `Users_Play` SET `Alert` = '".$row2['Alert']."Party:Left:".$Leaver.":".$NewLeader."|' 
						WHERE `Username` = '".$x."'";
						
				mysqli_query($con, $sql);
			}
		}  
	}
	echo $Return;
?>