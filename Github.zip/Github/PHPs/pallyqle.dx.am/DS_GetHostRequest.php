<?php

	require './src/DBInfo.php';
	
	$Return = "";
	$Region = $_POST["Region"];
        
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM DS_CreationRequest";
		$result = mysqli_query($con, $sql);
		
		if(mysqli_num_rows($result) > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{			
				if($row['Region'] == $Region)
				{
					$Return .= $row['ServerType'] . ";";

					$sql = "DELETE FROM DS_CreationRequest WHERE `RequestIndex` = '".$row['RequestIndex']."'";
					mysqli_query($con, $sql);
				}                                
			}                                          
		}
	}
	echo $Return;
?>