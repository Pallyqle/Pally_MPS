<?php
        
		require './src/DBInfo.php';
		
        $Return = "";
        $Username = $_REQUEST["Username"];
        $IP = $_REQUEST["IP"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
        if ($con->connect_errno) 
        {
                $Return = "Connect Failed";
                echo "{Content: \"".$Return."\"}"; 
                exit();
                $con->close();
        } 
        else
        {
                $sql = "INSERT INTO `DS_LoginRequest` (`RequestIndex`, `Username`, `IP`) VALUES (NULL, '$Username', '$IP')";
                mysqli_query($con, $sql);
                
                
                $Return = "Login Posted";
                echo "{Content: \"".$Return."\"}"; 
        }

?>