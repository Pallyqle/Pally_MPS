<?php

	require './src/DBInfo.php';

	$Return = "";
	$Inviter = $_REQUEST["Inviter"];
	$Members = $_REQUEST["Members"];
	$Invitee = $_REQUEST["Invitee"];        
	$IsSent = $_REQUEST["IsSent"]; 
	$IsUpdateSent = $_REQUEST["IsUpdateSent"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
			$Return = "Error0";
			exit();
			$con->close();
	} 
	else
	{		
		if($IsSent == 0)
		{			
			$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$Invitee."'";
			$row = mysqli_fetch_assoc(mysqli_query($con, $sql));
			
			if((strpos($row['Alert'], 'Party:Recv:'.$Inviter.'|') === false))
			{
				$sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Party:Recv:".$Inviter."|' 
					WHERE `Username` = '".$Invitee."'";
				mysqli_query($con, $sql);
			}
		}
		else 				
		{
			if($IsUpdateSent == 0)
			{				
				$MembersArray = explode(",", $Members);
				
				foreach($MembersArray as $x)
				{
					$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
					$row = mysqli_fetch_assoc(mysqli_query($con, $sql));
									 
					if((strpos($row['Alert'], 'Party:Sent:'.$Invitee.'|') === false))
					{
							$sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Party:Sent:".$Invitee."|' 
									WHERE `Username` = '".$x."'";
							mysqli_query($con, $sql);
					}
				}
			}
			else
			{
				$MembersArray = explode(",", $Member);
				foreach($MembersArray as $x)
				{					
					$sql = "SELECT * FROM Users_Play WHERE `Username` = '".$x."'";
					$row = mysqli_fetch_assoc(mysqli_query($con, $sql));
									 
					if((strpos($row['Alert'], 'Party:Sent:'.$Invitee.'|') === false))
					{
							$sql = "UPDATE `Users_Play` SET `Alert` = '".$row['Alert']."Party:Sent:".$Invitee."|' 
									WHERE `Username` = '".$x."'";
							mysqli_query($con, $sql);
					}
				}			
			}
		}
	}
        
?>