<?php

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require './src/Exception.php';
	require './src/PHPMailer.php';
	require './src/SMTP.php';
	require './src/DBInfo.php';
	
	$Return = "";
        
	$Username = $_REQUEST["Username"];   

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Save WHERE `Username` = '".$Username."' OR `Email` = '".$Username."'";;
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
		
			$row = mysqli_fetch_assoc($result);
			
			//If already verified
			if($row['Verification'] == 1)
			{
				$Return = "Success1";
			}
			else
			{
				$Verification = $row['Verification'];
				$Email = $row['Email'];
				
				// Resend verification to the address			
				$mail = new PHPMailer(true);

				$mail->SMTPDebug = 0;

				$mail->Host = "smtp.mboxhosting.com";
				$mail->SMTPAuth = true;
				$mail->Username = $DBEmail;
				$mail->Password = $DBPassword;
				$mail->SMTPSecure = "tls";
				$mail->Port = 465;
				$mail->setFrom("noreply@pallyqle.dx.am", "Pallyqle");
				$mail->addAddress($Email);
				$mail->isHTML(true);    
				$mail->Subject = "Email Verification Test";
				$mail->Body = '<h1> Thank you for trying my multiplayer system. </h1>
								<p> Click the link to verify your account: 
								<br> http://www.pallyqle.dx.am/Verification.php?Email='.$Email.'&Verification='.$Verification.'
								</p>
				';      					

				try 
				{
					$mail->send();
					$Return = "Success0";
				} 
				catch (Exception $e) 
				{
					$Return = "Error17";
				}
			}
		}
		else
		{
			$Return = "Error14";			   
		}
	}
	echo $Return; 
?>