<?php
        
	require './src/DBInfo.php';
	
	$Return = "";
        
	$UserID = $_REQUEST["UserID"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Char WHERE `UserID` = '".$UserID."'";
		$result = mysqli_query($con, $sql);
		if(mysqli_num_rows($result) > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{			
				$Return .= $row['Server']."/".$row['Name']."/".$row['Affiliation']."/".$row['XP']."/".$row['Status']."/".$row['Inv'].
						"/".$row['Equips']."/".$row['Skills']."/" .$row['Talents']."/".$row['Appearance'].
						"/".$row['Gameplay']."/".$row['Keybinds']."/".$row['KeyRemap']."/".$row['Chat'].";";
			}
		}
		else
		{
			$Return = "Success3";
		}
	}
	echo $Return;
?>