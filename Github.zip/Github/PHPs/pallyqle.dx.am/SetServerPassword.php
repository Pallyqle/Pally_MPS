<?php
        
	require './src/DBInfo.php';
		
	$Return = "";
	$IP = $_REQUEST["IP"];
	$Port = $_REQUEST["Port"];
	$Password = $_REQUEST["Password"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "UPDATE `Servers` SET `Password` = '".$Password."' WHERE `IP` = '".$IP."' && `Port` = '".$Port."'";
		mysqli_query($con, $sql);
		
		$Return = "Success7";
	}        
	echo $Return; 
?>