<?php

	require './src/DBInfo.php';

	$Return = "";
        
	$Username = $_REQUEST["Username"];
	$Leader = $_REQUEST["Leader"];
	$Members = $_REQUEST["Members"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		if($Members == "")
		{
			$sql = "UPDATE `Users_Play` SET `Leader` = '', `CurrentParty` = '' WHERE `Username` = '".$Username."'";
			mysqli_query($con, $sql);  
		}
		else
		{
			$MembersArray = explode("|", $Members);
			foreach($MembersArray as $x)
			{			
				$sql = "UPDATE `Users_Play` SET `Leader` = '".$Leader."', `CurrentParty` = '".$Members."' WHERE `Username` = '".$x."'";
				mysqli_query($con, $sql);		
			}    	
		}
	}
	echo $Return;
?>