<?php       

    $Return = $_SERVER['REMOTE_ADDR'];       
        
    echo $Return; 

?>