<?php

	require './src/DBInfo.php';
		
	$Return = "";        
	$UserID = $_REQUEST["UserID"];
	$PrevDevice = $_REQUEST["PrevDevice"];
	$Name = $_REQUEST["Name"];
	
	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0";
		exit();
		$con->close();
	} 
	else
	{
		$sql = "SELECT * FROM Users_Save WHERE `UserID` = '".$UserID."'";
		$result = mysqli_query($con, $sql);
		$row = mysqli_fetch_assoc($result);		
		
		// Check if logged in from another device
		if($row['PrevDevice'] == $PrevDevice)
		{
			$sql = "DELETE FROM Users_Char WHERE `Name` = '".$Name."'";
			mysqli_query($con, $sql);  

			$Return = "Success8";
		}
		else
		{
			$Return = "Prompt2"; 
		}
	}
	echo $Return; 
?>