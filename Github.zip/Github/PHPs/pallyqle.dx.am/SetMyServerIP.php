<?php

	require './src/DBInfo.php';

	$Return = "";
	$Username = $_REQUEST["Username"]; 
	$IP = $_REQUEST["IP"]; 
	$IsInstance = $_REQUEST["IsInstance"];

	$con = new mysqli($FTP, $DBUsername, $DBPassword, $DBName);
	if ($con->connect_errno) 
	{
		$Return = "Error0"; 
		exit();
		$con->close();
	} 
	else
	{
		if($IsInstance == 1)
		{
			$sql = "UPDATE `Users_Play` SET `InstanceIP` = '".$IP."' WHERE `Username` = '".$Username."'";
			mysqli_query($con, $sql);
		}
		else
		{
			$sql = "UPDATE `Users_Play` SET `MainIP` = '".$IP."' WHERE `Username` = '".$Username."'";
			mysqli_query($con, $sql);
		}   
		
		$Return = $IP;
	}
	echo $Return; 
?>